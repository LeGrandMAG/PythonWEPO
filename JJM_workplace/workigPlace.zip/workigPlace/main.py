import pandas as pd

df = pd.read_csv("facebookData_withProduct_afterMapped")

for i in range(len(df['raw'])):
    print(df['raw'][i], df['productMapped'][i])