import re
import pandas as pd

# 파이썬 딕셔너리 : https://bio-info.tistory.com/50

variations = {
    'Samsung': ['Samsung', 'Sam', 'Sm', 'Smg', 'Ss', 'Ssg', 'Samsung', 'Sam', 'Sm', 'Smg', 'Ss', 'Ssg', 'samsung',
                'samsung', 'sam', 'sm', 'smg', 'ss', 'ssg', 'samsung', 'sam', 'sm', 'smg', 'ss', 'ssg', 'samsung'],
    'Apple': ['Apple', 'Aple', 'apple', 'aple'],
    'Tecno': ['Tecno', 'Tehcno', 'Teco', 'tecno', 'tehcno', 'teco','Techno', 'techno'],
    'Galaxy': ['Galaxy', 'Glxy', 'Gal', 'galaxy', 'Glx', 'galaxy', 'glxy', 'gal', 'galaxy', 'glx'],
    'iPhone': ['iPhone', 'iPhon', 'iPhne', 'iPone', 'iphone', 'iphon', 'iphne', 'ipone'],
    'Camon': ['Camon', 'Camom', 'Canom', 'Kamon', 'Campn', 'camon', 'camom', 'canom', 'kamon', 'campn'],
    'Phantom': ['Phantom', 'Pantom', 'Pahntom', 'Phanton', 'Pamton', 'Phanton', 'Phamtom', 'Pamtom', 'Panton',
                'Pahnton', 'Pahmtom', 'Pahmton', 'phantom', 'pantom', 'pahntom', 'phanton', 'pamton', 'phanton',
                'phamtom', 'pamtom', 'panton', 'pahnton', 'pahmtom', 'pahmton'],
    'Pouvoir': ['Pouvoir', 'Povoir', 'Puvoir', 'Pouvoire', 'Pouvior', 'Povior', 'pouvoir', 'povoir', 'puvoir',
                'pouvoire', 'pouvior', 'povior'], 'Spark': ['Spark', 'Sprk', 'Spak', 'spack', 'spark', 'sprk', 'spak']
}
tag_low = {
    'company': ['samsung', 'apple', 'tecno'],
    'brand': ['iphone', 'galaxy'],
    'model': ['tab s7 fe', 'tab_s7_fe', 'tabs7fe', 's10', 'a8duos', 'a8_duos', 'a8 duos', 'a01core', 'a01 core', 'a01_core', 'a8_star_', 'a8 star ', 'a8star', 'a6 +', 'a6_+', 'a6+', 'a30 s', 'a30_s', 'a30s', 's20 ultra', 's20ultra', 's20_ultra', 'tabs8.4', 'tab_s_8.4', 'tab s 8.4', 'tab_s8', 'tabs8', 'tab s8', 's10_e', 's10e', 's10 e', 'a02 s', 'a02_s', 'a02s', 'tab_s6', 'tab s6', 'tabs6', 'a72', 'tabs8.4', 'tab_s_8.4', 'tab s 8.4', 's22 +', 's22+', 's22_+', 'tab s2 9.7', 'tab_s2_9.7', 'tabs29.7', 's10', 's9', 'tab a 8.0', 'tab_a_8.0', 'taba8.0', 'tab410.1', 'tab 4 10.1', 'tab_4_10.1', 'z_flip_3', 'z flip 3', 'zflip3', 's9_+', 's9+', 's9 +', 'a12nacho', 'a12 nacho', 'a12_nacho', 'tabs410.5', 'tab_s4_10.5', 'tab s4 10.5', 'a8_s', 'a8s', 'a8 s', 'tab_3_v', 'tab3v', 'tab 3 v', 'tab_pro_12.2', 'tabpro12.2', 'tab pro 12.2', 'a01', 'tabs8ultra', 'tab s8 ultra', 'tab_s8_ultra', 'tab_a8_10.5', 'tab a8 10.5', 'taba810.5', 'a10', 'a6', 'tab a 8.0 & s pen', 'taba8.0&spen', 'tab_a_8.0_&_s_pen', 'z_fold_4', 'zfold4', 'z fold 4', 'fold', 'a21', 's6', 'tab_4_7.0', 'tab 4 7.0', 'tab47.0', 'tab_s6', 'tab s6', 'tabs6', 'z_flip', 'z flip', 'zflip', 'a50', 'a40', 'a32', 's20 +', 's20+', 's20_+', 's20 fe', 's20fe', 's20_fe', 's22', 'a8', 'tab a7 10.4', 'tab_a7_10.4', 'taba710.4', 'a12', 'a9 pro', 'a9pro', 'a9_pro', 'tab_4_7.0', 'tab 4 7.0', 'tab47.0', 'fold', 'a02', 'note20ultra', 'note 20 ultra', 'note_20_ultra', 'z flip 4', 'z_flip_4', 'zflip4', 'note pro 12.2', 'note_pro_12.2', 'notepro12.2', 'tab_s7_+', 'tabs7+', 'tab s7 +', 'a03', 'note pro 12.2', 'note_pro_12.2', 'notepro12.2', 'tab s 10.5', 'tab_s_10.5', 'tabs10.5', 'a60', 'tabpro8.4', 'tab pro 8.4', 'tab_pro_8.4', 'a7_duos', 'a7duos', 'a7 duos', 'note10+', 'note_10_+', 'note 10 +', 'note 20', 'note_20', 'note20', 'taba9.7', 'tab a 9.7', 'tab_a_9.7', 'taba7.0', 'tab a 7.0', 'tab_a_7.0', 'a20s', 'a20_s', 'a20 s', 'note 20', 'note_20', 'note20', 'a33', 'tab_a_10.1', 'taba10.1', 'tab a 10.1', 'note10', 'note_10', 'note 10', 'a52', 'a9_star', 'a9 star', 'a9star', 'zfold3', 'z fold 3', 'z_fold_3', 'a21_s', 'a21s', 'a21 s', 'tab 4 8.0', 'tab_4_8.0', 'tab48.0', 'note_3_neo', 'note 3 neo', 'note3neo', 'tab a & s pen', 'tab_a_&_s_pen', 'taba&spen', 'a9', 'tabs6lite', 'tab_s6_lite', 'tab s6 lite', 'z_flip', 'z flip', 'zflip', 'a71uw', 'a71 uw', 'a71_uw', 'tabactive3', 'tab_active3', 'tab active3', 'tabs8+', 'tab s8 +', 'tab_s8_+', 'a32', 'a22', 'a51', 'tab_active_pro', 'tab active pro', 'tabactivepro', 'tab s3 9.7', 'tab_s3_9.7', 'tabs39.7', 'tabe8.0', 'tab e 8.0', 'tab_e_8.0', 'a73', 'note_4_duos', 'note4duos', 'note 4 duos', 'a50s', 'a50_s', 'a50 s', 'note5duos', 'note_5_duos', 'note 5 duos', 'note_fe', 'note fe', 'notefe', 'a03core', 'a03_core', 'a03 core', 'a23', 'a6_s', 'a6 s', 'a6s', 's8+', 's8_+', 's8 +', 'a51', 's20 ultra', 's20ultra', 's20_ultra', 'a3 duos', 'a3duos', 'a3_duos', 'tab 3 lite 7.0', 'tab3lite7.0', 'tab_3_lite_7.0', 'tab 4 8.0', 'tab_4_8.0', 'tab48.0', 'a13', 's8', 'note10+', 'note_10_+', 'note 10 +', 'note20ultra', 'note 20 ultra', 'note_20_ultra', 'a10_e', 'a10 e', 'a10e', 'tab a7 lite', 'tab_a7_lite', 'taba7lite', 's22ultra', 's22 ultra', 's22_ultra', 'note3neoduos', 'note_3_neo_duos', 'note 3 neo duos', 'note_5', 'note5', 'note 5', 'note pro 12.2', 'note_pro_12.2', 'notepro12.2', 'a52', 'a53', 'note_4', 'note 4', 'note4', 's21 +', 's21+', 's21_+', 'a41', 'a2_core', 'a2core', 'a2 core', 'note 9', 'note_9', 'note9', 'note_10_lite', 'note10lite', 'note 10 lite', 'tab_pro_12.2', 'tabpro12.2', 'tab pro 12.2', 'note_edge', 'note edge', 'noteedge', 'note10', 'note_10', 'note 10', 'tab410.1', 'tab 4 10.1', 'tab_4_10.1', 'tab j', 'tab_j', 'tabj', 's21', 'a13', 'a70', 'tab3lite7.0ve', 'tab 3 lite 7.0 ve', 'tab_3_lite_7.0_ve', 'note_8', 'note 8', 'note8', 'a71', 'a10s', 'a10_s', 'a10 s', 'a42', 'a03s', 'a03 s', 'a03_s', 'tab_pro_12.2', 'tabpro12.2', 'tab pro 12.2', 'tab e 9.6', 'tab_e_9.6', 'tabe9.6', 'a22', 's10+', 's10_+', 's10 +', 'a5', 'tabs5e', 'tab s5 e', 'tab_s5_e', 'a90', 'tabpro8.4', 'tab pro 8.4', 'tab_pro_8.4', 'tab s 10.5', 'tab_s_10.5', 'tabs10.5', 'tabadvanced2', 'tab advanced2', 'tab_advanced2', 's7', 'tab s2 8.0', 'tabs28.0', 'tab_s2_8.0', 'a20e', 'a20_e', 'a20 e', 'tab pro 10.1', 'tabpro10.1', 'tab_pro_10.1', 'a70_s', 'a70 s', 'a70s', 'a20', 'a31', 'tab pro 10.1', 'tabpro10.1', 'tab_pro_10.1', 's20 fe', 's20fe', 's20_fe', 'a51_uw', 'a51 uw', 'a51uw', 'z fold 2', 'zfold2', 'z_fold_2', 'tab 4 8.0', 'tab_4_8.0', 'tab48.0', 'tab_s7', 'tabs7', 'tab s7', 's21 ultra', 's21ultra', 's21_ultra', 'note7', 'note_7', 'note 7', 'taba8.4', 'tab a 8.4', 'tab_a_8.4', 'a71', 'a5 duos', 'a5duos', 'a5_duos', 'a3', 's21 fe', 's21_fe', 's21fe', 'taba10.5', 'tab_a_10.5', 'tab a 10.5', 's20', 'a30', 'tab410.1', 'tab 4 10.1', 'tab_4_10.1', 'tab_4_7.0', 'tab 4 7.0', 'tab47.0', 'a52_s', 'a52 s', 'a52s', 'a_quantum', 'a quantum', 'aquantum', 's20', 'tab 3 lite 7.0', 'tab3lite7.0', 'tab_3_lite_7.0', 'tabactive2', 'tab_active_2', 'tab active 2', 'a7', 'a80', 's20 +', 's20+', 's20_+', '7', '14_+', '14_plus', '14+', '14 +', '14plus', '14 plus', '11 pro max', '11promax', '11_pro_max', '6s +', '6s plus', '6s_plus', '6s+', '6splus', '6s_+', '14_pro', '14pro', '14 pro', '6s', 'xs', '8', '8 +', '8+', '8_+', '8 plus', '8plus', '8_plus', 'se 2 gen', 'se_2nd_gen', 'se2gen', 'se 2nd gen', 'se_2_gen', 'se2ndgen', 'se 2', 'se2', '11', 'se_1st_gen', 'se1stgen', 'se 1st gen', 'se1gen', 'se_1_gen', 'se 1 gen', 'se', 'se 1', 'se1', '6', 'x', '11pro', '11_pro', '11 pro', 'se_3_gen', 'se_3rd_gen', 'se 3rd gen', 'se3rdgen', 'se 3 gen', 'se3gen', 'se 3', 'se3', 'xr', '13 mini', '13_mini', '13mini', '12_pro_max', '12promax', '12 pro max', '12', 'xsmax', 'xs_max', 'xs max', '12pro', '12_pro', '12 pro', '13', '6plus', '6+', '6 +', '6_+', '6_plus', '6 plus', '14', '12mini', '12_mini', '12 mini', '7 +', '7+', '7_plus', '7_+', '7plus', '7 plus', '14 pro max', '14_pro_max', '14promax', '13_pro', '13pro', '13 pro', '13 pro max', '13promax', '13_pro_max', 'pouvoir2pro', 'pouvoir 2 pro', 'pouvoir_2_pro', 'poppro', 'pop pro', 'pop_pro', 'camoncm', 'camon_cm', 'camon cm', 'camon cx air', 'camoncxair', 'camon_cx_air', 'pop', 'f2_lte', 'f2 lte', 'f2lte', 'phantom_8', 'phantom 8', 'phantom8', 'poplite', 'pop_lite', 'pop lite', 'camonx', 'camon_x', 'camon x', 'phantom6+', 'phantom_6_plus', 'phantom 6 +', 'phantom 6 plus', 'phantom6plus', 'phantom_6_+', 'camon_11', 'camon 11', 'camon11', 'spark pro', 'spark_pro', 'sparkpro', 'spark_2', 'spark 2', 'spark2', 'phantom6', 'phantom_6', 'phantom 6', 'camon_cx', 'camon cx', 'camoncx', 'pop_s', 'pop s', 'pops', 'pouvoir', 'spark_plus', 'sparkplus', 'spark_+', 'spark +', 'spark plus', 'spark+', 'spark', 'f2', 'camon x pro', 'camonxpro', 'camon_x_pro', 'spark cm', 'spark_cm', 'sparkcm', 'pouvoir_2', 'pouvoir 2', 'pouvoir2'],
    'version': ['+', 'plus', '1', 'pro', 'max', 'gen']
}
allproducts = {
    'Samsung Galaxy Tab S7 FE': ['Tab S7 FE', 'Tab_S7_FE', 'TabS7FE'], 'Samsung Galaxy S10 5G': ['S10'],
    'Samsung Galaxy A8 Duos': ['A8Duos', 'A8_Duos', 'A8 Duos'],
    'Samsung Galaxy A01 Core': ['A01Core', 'A01 Core', 'A01_Core'],
    'Samsung Galaxy A8 Star ': ['A8_Star_', 'A8 Star ', 'A8Star'], 'Samsung Galaxy A6 +': ['A6 +', 'A6_+', 'A6+'],
    'Samsung Galaxy A30 s': ['A30 s', 'A30_s', 'A30s'],
    'Samsung Galaxy S20 Ultra LTE': ['S20 Ultra', 'S20Ultra', 'S20_Ultra'],
    'Samsung Galaxy Tab S 8.4 LTE': ['TabS8.4', 'Tab_S_8.4', 'Tab S 8.4'],
    'Samsung Galaxy Tab S8': ['Tab_S8', 'TabS8', 'Tab S8'], 'Samsung Galaxy S10 e': ['S10_e', 'S10e', 'S10 e'],
    'Samsung Galaxy A02 s': ['A02 s', 'A02_s', 'A02s'],
    'Samsung Galaxy Tab S6': ['Tab_S6', 'Tab S6', 'TabS6'], 'Samsung Galaxy A72': ['A72'],
    'Samsung Galaxy Tab S 8.4': ['TabS8.4', 'Tab_S_8.4', 'Tab S 8.4'],
    'Samsung Galaxy S22 + 5G': ['S22 +', 'S22+', 'S22_+'],
    'Samsung Galaxy Tab S2 9.7': ['Tab S2 9.7', 'Tab_S2_9.7', 'TabS29.7'], 'Samsung Galaxy S10': ['S10'],
    'Samsung Galaxy S9': ['S9'],
    'Samsung Galaxy Tab A 8.0': ['Tab A 8.0', 'Tab_A_8.0', 'TabA8.0'],
    'Samsung Galaxy Tab 4 10.1': ['Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1'],
    'Samsung Galaxy Z Flip 3 5G': ['Z_Flip_3', 'Z Flip 3', 'ZFlip3'],
    'Samsung Galaxy S9 +': ['S9_+', 'S9+', 'S9 +'], 'Samsung Galaxy A12 Nacho': ['A12Nacho', 'A12 Nacho', 'A12_Nacho'],
    'Samsung Galaxy Tab S4 10.5': ['TabS410.5', 'Tab_S4_10.5', 'Tab S4 10.5'],
    'Samsung Galaxy A8 s': ['A8_s', 'A8s', 'A8 s'], 'Samsung Galaxy Tab 3 V': ['Tab_3_V', 'Tab3V', 'Tab 3 V'],
    'Samsung Galaxy Tab Pro 12.2 3G': ['Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2'],
    'Samsung Galaxy A01': ['A01'], 'Samsung Galaxy Tab S8 Ultra': ['TabS8Ultra', 'Tab S8 Ultra', 'Tab_S8_Ultra'],
    'Samsung Galaxy Tab A8 10.5': ['Tab_A8_10.5', 'Tab A8 10.5', 'TabA810.5'],
    'Samsung Galaxy A10': ['A10'], 'Samsung Galaxy A6': ['A6'],
    'Samsung Galaxy Tab A 8.0 & S Pen': ['Tab A 8.0 & S Pen', 'TabA8.0&SPen', 'Tab_A_8.0_&_S_Pen'],
    'Samsung Galaxy Z Fold 4': ['Z_Fold_4', 'ZFold4', 'Z Fold 4'], 'Samsung Galaxy Fold': ['Fold'],
    'Samsung Galaxy A21': ['A21'], 'Samsung Galaxy S6': ['S6'],
    'Samsung Galaxy Tab 4 7.0': ['Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0'],
    'Samsung Galaxy Tab S6 5G': ['Tab_S6', 'Tab S6', 'TabS6'],
    'Samsung Galaxy Z Flip 5G': ['Z_Flip', 'Z Flip', 'ZFlip'],
    'Samsung Galaxy A50': ['A50'], 'Samsung Galaxy A40': ['A40'], 'Samsung Galaxy A32 5G': ['A32'],
    'Samsung Galaxy S20 + 5G': ['S20 +', 'S20+', 'S20_+'], 'Samsung Galaxy S20 FE': ['S20 FE', 'S20FE', 'S20_FE'],
    'Samsung Galaxy S22 5G': ['S22'], 'Samsung Galaxy A8': ['A8'],
    'Samsung Galaxy Tab A7 10.4': ['Tab A7 10.4', 'Tab_A7_10.4', 'TabA710.4'], 'Samsung Galaxy A12': ['A12'],
    'Samsung Galaxy A9 Pro': ['A9 Pro', 'A9Pro', 'A9_Pro'],
    'Samsung Galaxy Tab 4 7.0 LTE': ['Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0'], 'Samsung Galaxy Fold 5G': ['Fold'],
    'Samsung Galaxy A02': ['A02'],
    'Samsung Galaxy Note 20 Ultra 5G': ['Note20Ultra', 'Note 20 Ultra', 'Note_20_Ultra'],
    'Samsung Galaxy Z Flip 4': ['Z Flip 4', 'Z_Flip_4', 'ZFlip4'],
    'Samsung Galaxy Note Pro 12.2 5G': ['Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2'],
    'Samsung Galaxy Tab S7 +': ['Tab_S7_+', 'TabS7+', 'Tab S7 +'], 'Samsung Galaxy A03': ['A03'],
    'Samsung Galaxy Note Pro 12.2': ['Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2'],
    'Samsung Galaxy Tab S 10.5 LTE': ['Tab S 10.5', 'Tab_S_10.5', 'TabS10.5'], 'Samsung Galaxy A60': ['A60'],
    'Samsung Galaxy Tab Pro 8.4 3G/LTE': ['TabPro8.4', 'Tab Pro 8.4', 'Tab_Pro_8.4'],
    'Samsung Galaxy A7 Duos': ['A7_Duos', 'A7Duos', 'A7 Duos'],
    'Samsung Galaxy Note 10 + 5G': ['Note10+', 'Note_10_+', 'Note 10 +'],
    'Samsung Galaxy Note 20': ['Note 20', 'Note_20', 'Note20'],
    'Samsung Galaxy Tab A 9.7': ['TabA9.7', 'Tab A 9.7', 'Tab_A_9.7'],
    'Samsung Galaxy Tab A 7.0': ['TabA7.0', 'Tab A 7.0', 'Tab_A_7.0'],
    'Samsung Galaxy A20 s': ['A20s', 'A20_s', 'A20 s'], 'Samsung Galaxy Note 20 5G': ['Note 20', 'Note_20', 'Note20'],
    'Samsung Galaxy A33 5G': ['A33'],
    'Samsung Galaxy Tab A 10.1': ['Tab_A_10.1', 'TabA10.1', 'Tab A 10.1'],
    'Samsung Galaxy Note 10 5G': ['Note10', 'Note_10', 'Note 10'], 'Samsung Galaxy A52': ['A52'],
    'Samsung Galaxy A9 Star': ['A9_Star', 'A9 Star', 'A9Star'],
    'Samsung Galaxy Z Fold 3 5G': ['ZFold3', 'Z Fold 3', 'Z_Fold_3'],
    'Samsung Galaxy A21 s': ['A21_s', 'A21s', 'A21 s'],
    'Samsung Galaxy Tab 4 8.0': ['Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0'],
    'Samsung Galaxy Note 3 Neo': ['Note_3_Neo', 'Note 3 Neo', 'Note3Neo'],
    'Samsung Galaxy Tab A & S Pen': ['Tab A & S Pen', 'Tab_A_&_S_Pen', 'TabA&SPen'],
    'Samsung Galaxy A9': ['A9'], 'Samsung Galaxy Tab S6 Lite': ['TabS6Lite', 'Tab_S6_Lite', 'Tab S6 Lite'],
    'Samsung Galaxy Z Flip': ['Z_Flip', 'Z Flip', 'ZFlip'],
    'Samsung Galaxy A71 5G UW': ['A71UW', 'A71 UW', 'A71_UW'],
    'Samsung Galaxy Tab Active3': ['TabActive3', 'Tab_Active3', 'Tab Active3'],
    'Samsung Galaxy Tab S8 +': ['TabS8+', 'Tab S8 +', 'Tab_S8_+'],
    'Samsung Galaxy A32': ['A32'], 'Samsung Galaxy A22 5G': ['A22'], 'Samsung Galaxy A51': ['A51'],
    'Samsung Galaxy Tab Active Pro': ['Tab_Active_Pro', 'Tab Active Pro', 'TabActivePro'],
    'Samsung Galaxy Tab S3 9.7': ['Tab S3 9.7', 'Tab_S3_9.7', 'TabS39.7'],
    'Samsung Galaxy Tab E 8.0': ['TabE8.0', 'Tab E 8.0', 'Tab_E_8.0'], 'Samsung Galaxy A73 5G': ['A73'],
    'Samsung Galaxy Note 4 Duos': ['Note_4_Duos', 'Note4Duos', 'Note 4 Duos'],
    'Samsung Galaxy A50 s': ['A50s', 'A50_s', 'A50 s'],
    'Samsung Galaxy Note 5 Duos': ['Note5Duos', 'Note_5_Duos', 'Note 5 Duos'],
    'Samsung Galaxy Note FE': ['Note_FE', 'Note FE', 'NoteFE'],
    'Samsung Galaxy A03 Core': ['A03Core', 'A03_Core', 'A03 Core'], 'Samsung Galaxy A23': ['A23'],
    'Samsung Galaxy A6 s': ['A6_s', 'A6 s', 'A6s'],
    'Samsung Galaxy S8 +': ['S8+', 'S8_+', 'S8 +'], 'Samsung Galaxy A51 5G': ['A51'],
    'Samsung Galaxy S20 Ultra 5G': ['S20 Ultra', 'S20Ultra', 'S20_Ultra'],
    'Samsung Galaxy A3 Duos': ['A3 Duos', 'A3Duos', 'A3_Duos'],
    'Samsung Galaxy Tab 3 Lite 7.0 3G': ['Tab 3 Lite 7.0', 'Tab3Lite7.0', 'Tab_3_Lite_7.0'],
    'Samsung Galaxy Tab 4 8.0 3G': ['Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0'], 'Samsung Galaxy A13': ['A13'],
    'Samsung Galaxy S8': ['S8'], 'Samsung Galaxy Note 10 +': ['Note10+', 'Note_10_+', 'Note 10 +'],
    'Samsung Galaxy Note 20 Ultra': ['Note20Ultra', 'Note 20 Ultra', 'Note_20_Ultra'],
    'Samsung Galaxy A10 e': ['A10_e', 'A10 e', 'A10e'],
    'Samsung Galaxy Tab A7 Lite': ['Tab A7 Lite', 'Tab_A7_Lite', 'TabA7Lite'],
    'Samsung Galaxy S22 Ultra 5G': ['S22Ultra', 'S22 Ultra', 'S22_Ultra'],
    'Samsung Galaxy Note 3 Neo Duos': ['Note3NeoDuos', 'Note_3_Neo_Duos', 'Note 3 Neo Duos'],
    'Samsung Galaxy Note 5': ['Note_5', 'Note5', 'Note 5'],
    'Samsung Galaxy Note Pro 12.2 LTE': ['Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2'],
    'Samsung Galaxy A52 5G': ['A52'], 'Samsung Galaxy A53 5G': ['A53'],
    'Samsung Galaxy Note 4': ['Note_4', 'Note 4', 'Note4'], 'Samsung Galaxy S21 + 5G': ['S21 +', 'S21+', 'S21_+'],
    'Samsung Galaxy A41': ['A41'], 'Samsung Galaxy A2 Core': ['A2_Core', 'A2Core', 'A2 Core'],
    'Samsung Galaxy Note 9': ['Note 9', 'Note_9', 'Note9'],
    'Samsung Galaxy Note 10 Lite': ['Note_10_Lite', 'Note10Lite', 'Note 10 Lite'],
    'Samsung Galaxy Tab Pro 12.2 LTE': ['Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2'],
    'Samsung Galaxy Note Edge': ['Note_Edge', 'Note Edge', 'NoteEdge'],
    'Samsung Galaxy Note 10': ['Note10', 'Note_10', 'Note 10'],
    'Samsung Galaxy Tab 4 10.1 LTE': ['Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1'],
    'Samsung Galaxy Tab J': ['Tab J', 'Tab_J', 'TabJ'], 'Samsung Galaxy S21 5G': ['S21'],
    'Samsung Galaxy A13 5G': ['A13'], 'Samsung Galaxy A70': ['A70'],
    'Samsung Galaxy Tab 3 Lite 7.0 VE': ['Tab3Lite7.0VE', 'Tab 3 Lite 7.0 VE', 'Tab_3_Lite_7.0_VE'],
    'Samsung Galaxy Note 8': ['Note_8', 'Note 8', 'Note8'], 'Samsung Galaxy A71 5G': ['A71'],
    'Samsung Galaxy A10 s': ['A10s', 'A10_s', 'A10 s'], 'Samsung Galaxy A42 5G': ['A42'],
    'Samsung Galaxy A03 s': ['A03s', 'A03 s', 'A03_s'],
    'Samsung Galaxy Tab Pro 12.2': ['Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2'],
    'Samsung Galaxy Tab E 9.6': ['Tab E 9.6', 'Tab_E_9.6', 'TabE9.6'], 'Samsung Galaxy A22': ['A22'],
    'Samsung Galaxy S10 +': ['S10+', 'S10_+', 'S10 +'], 'Samsung Galaxy A5': ['A5'],
    'Samsung Galaxy Tab S5 e': ['TabS5e', 'Tab S5 e', 'Tab_S5_e'], 'Samsung Galaxy A90 5G': ['A90'],
    'Samsung Galaxy Tab Pro 8.4': ['TabPro8.4', 'Tab Pro 8.4', 'Tab_Pro_8.4'],
    'Samsung Galaxy Tab S 10.5': ['Tab S 10.5', 'Tab_S_10.5', 'TabS10.5'],
    'Samsung Galaxy Tab Advanced2': ['TabAdvanced2', 'Tab Advanced2', 'Tab_Advanced2'], 'Samsung Galaxy S7': ['S7'],
    'Samsung Galaxy Tab S2 8.0': ['Tab S2 8.0', 'TabS28.0', 'Tab_S2_8.0'],
    'Samsung Galaxy A20 e': ['A20e', 'A20_e', 'A20 e'],
    'Samsung Galaxy Tab Pro 10.1': ['Tab Pro 10.1', 'TabPro10.1', 'Tab_Pro_10.1'],
    'Samsung Galaxy A70 s': ['A70_s', 'A70 s', 'A70s'], 'Samsung Galaxy A20': ['A20'], 'Samsung Galaxy A31': ['A31'],
    'Samsung Galaxy Tab Pro 10.1 LTE': ['Tab Pro 10.1', 'TabPro10.1', 'Tab_Pro_10.1'],
    'Samsung Galaxy S20 FE 5G': ['S20 FE', 'S20FE', 'S20_FE'],
    'Samsung Galaxy A51 5G UW': ['A51_UW', 'A51 UW', 'A51UW'],
    'Samsung Galaxy Z Fold 2 5G': ['Z Fold 2', 'ZFold2', 'Z_Fold_2'],
    'Samsung Galaxy Tab 4 8.0 LTE': ['Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0'],
    'Samsung Galaxy Tab S7': ['Tab_S7', 'TabS7', 'Tab S7'],
    'Samsung Galaxy S21 Ultra 5G': ['S21 Ultra', 'S21Ultra', 'S21_Ultra'],
    'Samsung Galaxy Note 7': ['Note7', 'Note_7', 'Note 7'],
    'Samsung Galaxy Tab A 8.4': ['TabA8.4', 'Tab A 8.4', 'Tab_A_8.4'], 'Samsung Galaxy A71': ['A71'],
    'Samsung Galaxy A5 Duos': ['A5 Duos', 'A5Duos', 'A5_Duos'],
    'Samsung Galaxy A3': ['A3'], 'Samsung Galaxy S21 FE 5G': ['S21 FE', 'S21_FE', 'S21FE'],
    'Samsung Galaxy Tab A 10.5': ['TabA10.5', 'Tab_A_10.5', 'Tab A 10.5'], 'Samsung Galaxy S20': ['S20'],
    'Samsung Galaxy A30': ['A30'], 'Samsung Galaxy Tab 4 10.1 3G': ['Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1'],
    'Samsung Galaxy Tab 4 7.0 3G': ['Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0'],
    'Samsung Galaxy A52 s 5G': ['A52_s', 'A52 s', 'A52s'],
    'Samsung Galaxy A Quantum': ['A_Quantum', 'A Quantum', 'AQuantum'], 'Samsung Galaxy S20 5G': ['S20'],
    'Samsung Galaxy Tab 3 Lite 7.0': ['Tab 3 Lite 7.0', 'Tab3Lite7.0', 'Tab_3_Lite_7.0'],
    'Samsung Galaxy Tab Active 2': ['TabActive2', 'Tab_Active_2', 'Tab Active 2'], 'Samsung Galaxy A7': ['A7'],
    'Samsung Galaxy A80': ['A80'], 'Samsung Galaxy S20 +': ['S20 +', 'S20+', 'S20_+'],

    'iPhone 7': ['7'], 'iPhone 14 Plus': ['14_+', '14_Plus', '14+', '14 +', '14Plus', '14 Plus'],
    'iPhone 11 Pro Max': ['11 Pro Max', '11ProMax', '11_Pro_Max'], 'iPhone 6S Plus': ['6S +', '6S Plus', '6S_Plus', '6S+', '6SPlus', '6S_+'],
    'iPhone 14 Pro': ['14_Pro', '14Pro', '14 Pro'], 'iPhone 6S': ['6S'], 'iPhone XS': ['XS'], 'iPhone 8': ['8'], 'iPhone 8 Plus': ['8 +', '8+', '8_+', '8 Plus', '8Plus', '8_Plus'],
    'iPhone SE (2nd gen)': ['SE 2 gen', 'SE_2nd_gen', 'SE2gen', 'SE 2nd gen', 'SE_2_gen', 'SE2ndgen', 'SE 2', 'SE2'], 'iPhone 11': ['11'],
    'iPhone SE (1st gen)': ['SE_1st_gen', 'SE1stgen', 'SE 1st gen', 'SE1gen', 'SE_1_gen', 'SE 1 gen', 'SE', 'SE 1', 'SE1'], 'iPhone 6': ['6'], 'iPhone X': ['X'], 'iPhone 11 Pro': ['11Pro', '11_Pro', '11 Pro'],
    'iPhone SE (3rd gen)': ['SE_3_gen', 'SE_3rd_gen', 'SE 3rd gen', 'SE3rdgen', 'SE 3 gen', 'SE3gen', 'SE 3', 'SE3'], 'iPhone XR': ['XR'], 'iPhone 13 mini': ['13 mini', '13_mini', '13mini'],
    'iPhone 12 Pro Max': ['12_Pro_Max', '12ProMax', '12 Pro Max'], 'iPhone 12': ['12'], 'iPhone XS Max': ['XSMax', 'XS_Max', 'XS Max'], 'iPhone 12 Pro': ['12Pro', '12_Pro', '12 Pro'], 'iPhone 13': ['13'],
    'iPhone 6 Plus': ['6Plus', '6+', '6 +', '6_+', '6_Plus', '6 Plus'], 'iPhone 14': ['14'], 'iPhone 12 mini': ['12mini', '12_mini', '12 mini'], 'iPhone 7 Plus': ['7 +', '7+', '7_Plus', '7_+', '7Plus', '7 Plus'],
    'iPhone 14 Pro Max': ['14 Pro Max', '14_Pro_Max', '14ProMax'], 'iPhone 13 Pro': ['13_Pro', '13Pro', '13 Pro'], 'iPhone 13 Pro Max': ['13 Pro Max', '13ProMax', '13_Pro_Max'],

    'Tecno Pouvoir 2 Pro': ['Pouvoir2Pro', 'Pouvoir 2 Pro', 'Pouvoir_2_Pro'], 'Tecno Pop Pro': ['PopPro', 'Pop Pro', 'Pop_Pro'], 'Tecno Camon CM': ['CamonCM', 'Camon_CM', 'Camon CM'],
    'Tecno Camon CX Air': ['Camon CX Air', 'CamonCXAir', 'Camon_CX_Air'], 'Tecno Pop': ['Pop'], 'Tecno F2 LTE': ['F2_LTE', 'F2 LTE', 'F2LTE'],
    'Tecno Phantom 8': ['Phantom_8', 'Phantom 8', 'Phantom8'], 'Tecno Pop Lite': ['PopLite', 'Pop_Lite', 'Pop Lite'],
    'Tecno Camon X': ['CamonX', 'Camon_X', 'Camon X'], 'Tecno Phantom 6 Plus': ['Phantom6+', 'Phantom_6_Plus', 'Phantom 6 +', 'Phantom 6 Plus', 'Phantom6Plus', 'Phantom_6_+'],
    'Tecno Camon 11': ['Camon_11', 'Camon 11', 'Camon11'], 'Tecno Spark Pro': ['Spark Pro', 'Spark_Pro', 'SparkPro'],
    'Tecno Spark 2': ['Spark_2', 'Spark 2', 'Spark2'], 'Tecno Phantom 6': ['Phantom6', 'Phantom_6', 'Phantom 6'],
    'Tecno Camon CX': ['Camon_CX', 'Camon CX', 'CamonCX'], 'Tecno Pop s': ['Pop_s', 'Pop s', 'Pops'], 'Tecno Pouvoir': ['Pouvoir'],
    'Tecno Spark Plus': ['Spark_Plus', 'SparkPlus', 'Spark_+', 'Spark +', 'Spark Plus', 'Spark+'], 'Tecno Spark': ['Spark'], 'Tecno F2': ['F2'],
    'Tecno Camon X Pro': ['Camon X Pro', 'CamonXPro', 'Camon_X_Pro'], 'Tecno Spark CM': ['Spark CM', 'Spark_CM', 'SparkCM'],
    'Tecno Pouvoir 2': ['Pouvoir_2', 'Pouvoir 2', 'Pouvoir2']
}


# 퍼뮤테이션 알고리즘// 재귀함수를 이용한 조합 만들기 출처, https://kjhoon0330.tistory.com/15
def combination(arr, n):
    out = []
    if n == 0:
        return [[]]
    for i in range(len(arr)):
        t = arr[i]
        for e in t:
            for rest in combination(arr[i + 1:], n - 1):
                out.append([e] + rest)
    return out


# make variation
def generate_variation(str, line):
    variations = []
    splited = re.split("\s", str)

    # 1st rule : 첫 3글자
    arr = []
    for w in splited:
        t = []
        t.append(w)
        # variations.append(w)

        t.append(w[:3])
        # variations.append(w[:3])
        arr.append(t)
    f = combination(arr, len(arr))
    for words in f:
        t = ""
        for w in words:
            t = t + w
        variations.append(t)

    # 2rd rule : 모음앞에 있는 단어 조합
    temp = re.findall(r"(\w{0,2})[aeiouy]", str, re.IGNORECASE)  # 모음 앞에 있는 녀석들 추출
    arr = []
    for word in temp:
        t = []
        for a in word:
            t.append(a)
        arr.append(t)
    f = combination(arr, len(arr))

    for words in f:
        t = ""
        for w in words:
            t = t + w
        variations.append(t)
        variations.append(t + str[-1])

    # 대문자 기준으로 나누기 + 붙여쓰기, 띄어쓰기 모두 만들기
    arr = []
    for word in variations:
        t = re.findall(r"([A-Z][a-z]*)", word)
        stemp = ""
        for li in t:
            arr.append(li)
            stemp = stemp + " " + li
            stemp = re.findall("\s*(.+)", stemp)[0]
            arr.append(stemp)

    variations = variations + arr

    ##### line에서 찾기 #####

    # 첫글자와 마지막글자가 같은 문자
    variations = variations + re.findall(r"{}\w*{}".format(str[0], str[-1]), line, re.IGNORECASE)

    return variations


##################### trial #####################

# variation => real name 으로
rawDf = pd.read_csv("facebookData")
original = []
outPut = []
for line in rawDf['raw']:
    original.append(line)
    temp = re.split('\s', str(line))
    for realname in variations:
        for var in variations[realname]:
            for i in range(len(temp)):
                if re.search(r'{}'.format(var), temp[i]):
                    if len(var) == len(temp[i]):
                        temp[i] = realname
    outPut.append(' '.join(temp).lower())

# product tagging
docs = []
functionWords = ['+', '.', '*', '?']
for line in outPut:
    temp = re.split('\s', line)
    text = []
    for word in temp:
        x = 0
        for tagName in tag_low:
            for t in tag_low[tagName]:
                r = r"{}"
                if t in functionWords:
                    r = r'[{}]'
                    if re.search(r.format(t), word) and t == word:
                        text.append((word, 'N', tagName))
                        x=1
                    r = r"{}"
                else:
                    if t == word:
                        text.append((word, 'N', tagName))
                        x=1
        if x == 0:
            text.append((word, 'I', 'OUT'))
    docs.append(text)
productFromDocs = []
for labeled in docs:
    productName = []
    for tuples in labeled:

        if tuples[1] == 'N':
            productName.append(tuples[0])
    productFromDocs.append(list(set(productName)))

# for i in range(len(rawDf['raw'])):
#     print(i,rawDf['raw'][i], productFromDocs[i])

rawDf["product"] = productFromDocs
for i in rawDf['product']:
    print(i)
# mapping to formal product
rawDf.to_csv("facebookData_withProduct")


