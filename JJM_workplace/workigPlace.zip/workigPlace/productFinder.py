import re
import pandas as pd
import itertools

## raw data form
formalProductNames = """Samsung Galaxy S6
    Samsung Galaxy S7
    Samsung Galaxy S8
    Samsung Galaxy S8 +
    Samsung Galaxy S9
    Samsung Galaxy S9 +
    Samsung Galaxy S10
    Samsung Galaxy S10 +
    Samsung Galaxy S10 e
    Samsung Galaxy S10 5G
    Samsung Galaxy S20
    Samsung Galaxy S20 +
    Samsung Galaxy S20 Ultra 5G
    Samsung Galaxy S20 + 5G
    Samsung Galaxy S20 5G
    Samsung Galaxy S20 Ultra LTE
    Samsung Galaxy S20 FE
    Samsung Galaxy S20 FE 5G
    Samsung Galaxy S21 5G
    Samsung Galaxy S21 + 5G
    Samsung Galaxy S21 Ultra 5G
    Samsung Galaxy S21 FE 5G
    Samsung Galaxy S22 5G
    Samsung Galaxy S22 + 5G
    Samsung Galaxy S22 Ultra 5G
    Samsung Galaxy S20 FE 2022
    Samsung Galaxy A5 Duos
    Samsung Galaxy A5 Duos
    Samsung Galaxy A3
    Samsung Galaxy A3 Duos
    Samsung Galaxy A5
    Samsung Galaxy A7
    Samsung Galaxy A7 Duos
    Samsung Galaxy A8
    Samsung Galaxy A8 Duos
    Samsung Galaxy A3 (2016)
    Samsung Galaxy A5 (2016)
    Samsung Galaxy A7 (2016)
    Samsung Galaxy A9 (2016)
    Samsung Galaxy A9 Pro (2016)
    Samsung Galaxy A8 (2016)
    Samsung Galaxy A3 (2017)
    Samsung Galaxy A5 (2017)
    Samsung Galaxy A7 (2017)
    Samsung Galaxy A6 (2018)
    Samsung Galaxy A6 + (2018)
    Samsung Galaxy A8 Star 
    Samsung Galaxy A9 Star
    Samsung Galaxy A7 (2018)
    Samsung Galaxy A9 (2018)
    Samsung Galaxy A6 s
    Samsung Galaxy A8 s
    Samsung Galaxy A10
    Samsung Galaxy A20
    Samsung Galaxy A20 e
    Samsung Galaxy A30
    Samsung Galaxy A40
    Samsung Galaxy A50
    Samsung Galaxy A60
    Samsung Galaxy A70
    Samsung Galaxy A2 Core
    Samsung Galaxy A80
    Samsung Galaxy A10 e
    Samsung Galaxy A10 s
    Samsung Galaxy A50 s
    Samsung Galaxy A30 s
    Samsung Galaxy A90 5G
    Samsung Galaxy A70 s
    Samsung Galaxy A20 s
    Samsung Galaxy A51
    Samsung Galaxy A71
    Samsung Galaxy A01
    Samsung Galaxy A31
    Samsung Galaxy A51 5G
    Samsung Galaxy A41
    Samsung Galaxy A Quantum
    Samsung Galaxy A21 s
    Samsung Galaxy A71 5G
    Samsung Galaxy A21
    Samsung Galaxy A01 Core
    Samsung Galaxy A71 5G UW
    Samsung Galaxy A51 5G UW
    Samsung Galaxy A42 5G
    Samsung Galaxy A12
    Samsung Galaxy A02 s
    Samsung Galaxy A32 5G
    Samsung Galaxy A02
    Samsung Galaxy A32
    Samsung Galaxy A52 5G
    Samsung Galaxy A52
    Samsung Galaxy A72
    Samsung Galaxy A22
    Samsung Galaxy A22 5G
    Samsung Galaxy A12 Nacho
    Samsung Galaxy A03 s
    Samsung Galaxy A52 s 5G
    Samsung Galaxy A03 Core
    Samsung Galaxy A03
    Samsung Galaxy A13 5G
    Samsung Galaxy A13
    Samsung Galaxy A23
    Samsung Galaxy A33 5G
    Samsung Galaxy A53 5G
    Samsung Galaxy A73 5G
    Samsung Galaxy Note Pro 12.2
    Samsung Galaxy Note 3 Neo
    Samsung Galaxy Note 3 Neo Duos
    Samsung Galaxy Note Pro 12.2 5G
    Samsung Galaxy Note Pro 12.2 LTE
    Samsung Galaxy Note 4
    Samsung Galaxy Note 4 Duos
    Samsung Galaxy Note Edge
    Samsung Galaxy Note 5 Duos
    Samsung Galaxy Note 5
    Samsung Galaxy Note 7
    Samsung Galaxy Note FE
    Samsung Galaxy Note 8
    Samsung Galaxy Note 9
    Samsung Galaxy Note 10
    Samsung Galaxy Note 10 5G
    Samsung Galaxy Note 10 +
    Samsung Galaxy Note 10 + 5G
    Samsung Galaxy Note 10 Lite
    Samsung Galaxy Note 20
    Samsung Galaxy Note 20 5G
    Samsung Galaxy Note 20 Ultra
    Samsung Galaxy Note 20 Ultra 5G
    Samsung Galaxy Tab Pro 8.4
    Samsung Galaxy Tab 3 Lite 7.0
    Samsung Galaxy Tab Pro 8.4 3G/LTE
    Samsung Galaxy Tab Pro 10.1
    Samsung Galaxy Tab Pro 10.1 LTE
    Samsung Galaxy Tab Pro 12.2
    Samsung Galaxy Tab Pro 12.2 3G
    Samsung Galaxy Tab Pro 12.2 LTE
    Samsung Galaxy Tab 3 Lite 7.0 3G
    Samsung Galaxy Tab 4 7.0 LTE
    Samsung Galaxy Tab 4 7.0 3G
    Samsung Galaxy Tab 4 7.0
    Samsung Galaxy Tab 4 10.1 LTE
    Samsung Galaxy Tab 4 10.1 3G
    Samsung Galaxy Tab 4 10.1
    Samsung Galaxy Tab 4 8.0 LTE
    Samsung Galaxy Tab 4 8.0 3G
    Samsung Galaxy Tab 4 8.0
    Samsung Galaxy Tab S 10.5
    Samsung Galaxy Tab S 10.5 LTE
    Samsung Galaxy Tab S 8.4
    Samsung Galaxy Tab S 8.4 LTE
    Samsung Galaxy Tab 3 Lite 7.0 VE
    Samsung Galaxy Tab 3 V
    Samsung Galaxy Tab A 8.0
    Samsung Galaxy Tab A 9.7
    Samsung Galaxy Tab A & S Pen
    Samsung Galaxy Tab 4 10.1 (2015)
    Samsung Galaxy Tab E 9.6
    Samsung Galaxy Tab S2 8.0
    Samsung Galaxy Tab S2 9.7
    Samsung Galaxy Tab E 8.0
    Samsung Galaxy Tab A 7.0 (2016)
    Samsung Galaxy Tab A 10.1 (2016)
    Samsung Galaxy Tab J
    Samsung Galaxy Tab S3 9.7
    Samsung Galaxy Tab A 8.0 (2017)
    Samsung Galaxy Tab Active 2
    Samsung Galaxy Tab A 10.5
    Samsung Galaxy Tab S4 10.5
    Samsung Galaxy Tab A 8.0 (2018)
    Samsung Galaxy Tab Advanced2
    Samsung Galaxy Tab A 8.0 & S Pen (2019)
    Samsung Galaxy Tab A 10.1 (2019)
    Samsung Galaxy Tab S5 e
    Samsung Galaxy Tab A 8.0 (2019)
    Samsung Galaxy Tab S6
    Samsung Galaxy Tab Active Pro
    Samsung Galaxy Tab S6 5G
    Samsung Galaxy Tab A 8.4 (2020)
    Samsung Galaxy Tab S6 Lite
    Samsung Galaxy Tab S7
    Samsung Galaxy Tab S7 +
    Samsung Galaxy Tab A7 10.4 (2020)
    Samsung Galaxy Tab Active3
    Samsung Galaxy Tab S7 FE
    Samsung Galaxy Tab A7 Lite
    Samsung Galaxy Tab A8 10.5 (2021)
    Samsung Galaxy Tab S8
    Samsung Galaxy Tab S8 +
    Samsung Galaxy Tab S8 Ultra
    Samsung Galaxy Tab S6 Lite (2022)
    Samsung Galaxy Fold
    Samsung Galaxy Fold 5G
    Samsung Galaxy Z Fold 2 5G
    Samsung Galaxy Z Fold 3 5G
    Samsung Galaxy Z Flip
    Samsung Galaxy Z Flip 5G
    Samsung Galaxy Z Flip 3 5G
    Samsung Galaxy Z Fold 4
    Samsung Galaxy Z Flip 4
    Apple iPhone 6
    Apple iPhone 6 Plus
    Apple iPhone 6S
    Apple iPhone 6S Plus
    Apple iPhone SE (1st gen)
    Apple iPhone 7
    Apple iPhone 7 Plus
    Apple iPhone 8
    Apple iPhone 8 Plus
    Apple iPhone X
    Apple iPhone XR
    Apple iPhone XS
    Apple iPhone XS Max
    Apple iPhone 11
    Apple iPhone 11 Pro
    Apple iPhone 11 Pro Max
    Apple iPhone SE (2nd gen)
    Apple iPhone 12
    Apple iPhone 12 mini
    Apple iPhone 12 Pro
    Apple iPhone 12 Pro Max
    Apple iPhone 13
    Apple iPhone 13 mini
    Apple iPhone 13 Pro
    Apple iPhone 13 Pro Max
    Apple iPhone SE (3rd gen)
    Apple iPhone 14
    Apple iPhone 14 Plus
    Apple iPhone 14 Pro
    Apple iPhone 14 Pro Max
    Tecno Spark Plus
    Tecno Spark Pro
    Tecno Phantom 6
    Tecno Pop Lite
    Tecno Pouvoir 2 Pro
    Tecno Phantom 6 Plus
    Tecno Pouvoir
    Tecno Pop
    Tecno Spark CM
    Tecno Spark
    Tecno Camon CM
    Tecno F2 LTE
    Tecno Camon CX Air
    Tecno Camon CX
    Tecno Pouvoir 2
    Tecno Pop Pro
    Tecno Pop s
    Tecno Camon X
    Tecno Spark 2
    Tecno Camon X Pro
    Tecno Phantom 8
    Tecno Camon 11
    Tecno Spark Go
    Tecno Spark 8
    Tecno Spark 8 Pro
    Tecno F2"""
stop = ["5g", "lte", "3g"]
# variarion should be modified by human
variation = {
    'samsung': ['ss', 'smg', 'ssg', 'sam', 'sm', 'samsung'],
    'galaxy': ['galaxy', 'gal', 'glxy', 'glx'],
    'ultra': ['ult', 'ultra', 'u', 'ul'],
    'quantum': ['quantum', 'qantum', 'quontum', 'qauntum'],
    'advanced2': ['adv2', 'advanced2'],
    'iphone': ['iphone', 'iph'],
    'tecno': ['tecn', 'tecno', 'techno'],
    'spark': ['spark', 'spak'],
    'phantom': ['phantom', 'pantom', 'pahntom'],
    'pouvoir': ['pvr', 'pouvoir', 'pouvor', 'povir', 'pouvior', 'povoir']
}

## generate variation for word longer than 5words
# 퍼뮤테이션 알고리즘// 재귀함수를 이용한 조합 만들기 출처, https://kjhoon0330.tistory.com/15
def combination(arr, n):
    out = []
    if n == 0:
        return [[]]
    for i in range(len(arr)):
        t = arr[i]
        for e in t:
            for rest in combination(arr[i + 1:], n - 1):
                out.append([e] + rest)
    return out

# make variation with fomal word and line and we need to add more rules if we need.
def generate_variation(str, line):
    variations = []
    splited = re.split("\s", str)

    # 1st rule : 첫 3글자
    arr = []
    for w in splited:
        t = []
        t.append(w)
        # variations.append(w)

        t.append(w[:3])
        # variations.append(w[:3])
        arr.append(t)
    f = combination(arr, len(arr))
    for words in f:
        t = ""
        for w in words:
            t = t + w
        variations.append(t)

    # 2rd rule : 모음앞에 있는 단어 조합
    temp = re.findall(r"(\w{0,2})[aeiouy]", str, re.IGNORECASE)  # 모음 앞에 있는 녀석들 추출
    arr = []
    for word in temp:
        t = []
        for a in word:
            t.append(a)
        arr.append(t)
    f = combination(arr, len(arr))

    for words in f:
        t = ""
        for w in words:
            t = t + w
        variations.append(t)
        variations.append(t + str[-1])

    # 대문자 기준으로 나누기 + 붙여쓰기, 띄어쓰기 모두 만들기
    arr = []
    for word in variations:
        t = re.findall(r"([A-Z][a-z]*)", word)
        stemp = ""
        for li in t:
            arr.append(li)
            stemp = stemp + " " + li
            stemp = re.findall("\s*(.+)", stemp)[0]
            arr.append(stemp)

    variations = variations + arr

    ##### line에서 찾기 #####

    # 첫글자와 마지막글자가 같은 문자
    variations = variations + re.findall(r"{}\w*{}".format(str[0], str[-1]), line, re.IGNORECASE)

    return variations


############### Start! ###############

# # if no variation, make new variation
# rawDf = pd.read_csv("facebookData")
# variation = {}
# print(var)
# formalNameList = re.split("\n", formalProductNames)
# for text in formalNameList:
#     text = text.strip()
#     words = re.split('\s', text)
#     for w in words:
#         string = re.search('\w*', w.lower()).group()
#         if string and len(string) >= 5:
#             for line in rawDf['raw']:
#                 tempVar = generate_variation(string, str(line))
#             variation[w.lower()] = list(set(tempVar))

# generate tag and candidates
tag = {}
candidates = {}

rawDf = pd.read_csv("facebookData")
formalNameList = re.split("\n", formalProductNames)
companyTags = []
brandTags = []
modelTags = []
for text in formalNameList:
    text = text.strip().lower()
    words = re.split('\s', text)
    companyTags.append(words[0]) # make company tag
    brandTags.append(words[1]) # make brand tag

    for i in range(len(words[2:])) :
        words[i+2] = re.sub("\W", "", words[i+2])
        # make model tag
        if words[i+2] and words[i+2] not in stop:
            modelTags.append(words[i+2])

    # make possible model combinations
    candidatesList = []
    if len(words) >= 2:
        for count in range(len(words)):
            if count <= len(words):
                for com in itertools.combinations(words[1:], count+1):
                    candidatesList.append(' '.join(com))
                    candidatesList.append(''.join(com))
        candidates[text] = list(set(candidatesList))

# allocate tag
tag["company"] = list(set(companyTags))
tag["brand"] = list(set(brandTags))
tag["model"] = list(set(modelTags))

print("this is tags : ", tag)
for name in candidates:
    print("this is name : ", name)
    print(candidates[name])


# variation => real name 으로
rawDf = pd.read_csv("facebookData")

lines = []
for li in rawDf['raw']:
    tempLine = re.sub("[+]", 'plus', str(li))
    lines.append(tempLine)

changedToFomalname = []
for line in lines:
    temp = re.split('\s', str(line))
    for realname in variation:
        for var in variation[realname]:
            for i in range(len(temp)):
                if re.search(r'{}'.format(var), temp[i]):
                    if len(var) == len(temp[i]):
                        temp[i] = realname
    changedToFomalname.append(' '.join(temp).lower())


######################## product tagging
docs = []
# functionWords = ['+', '.', '*', '?']
for line in changedToFomalname:
    temp = re.split('\s', line)
    text = []
    for word in temp:
        x = 0
        for tagName in tag:
            for t in tag[tagName]:
                r = r"{}"
                if re.search(r.format(t), word) and t == word:
                    text.append((word, 'N', tagName))
                    x=1
                elif t == word:
                    text.append((word, 'N', tagName))
                    x=1
        if x == 0:
            text.append((word, 'I', 'OUT'))
    docs.append(text)

# for d in docs:
#     print(d)

productFromDocs = []
for labeled in docs:
    productName = []
    for tuples in labeled:

        if tuples[1] == 'N':
            productName.append(tuples[0])
    productFromDocs.append(list(set(productName)))


################################ mapping to formal product
# rawDf.to_csv("facebookData_withProduct")
fomalName = []
for token in productFromDocs:
    compareList = []
    if len(token) >= 2:
        for count in range(len(token)):
            if count <= len(token):
                for com in itertools.permutations(token, count+1):
                    compareList.append(' '.join(com))

    tempCompare = []
    # 비교 시작
    for var in compareList:
        for productName in candidates:
            if var in candidates[productName]:
                tempCompare.append(productName)

    fomalName.append(tempCompare)


final = []
# 전체 연결후 아닌거 빼내기
for i in range(len(fomalName)):
    arr = {}
    if len(fomalName[i]) >= 2:
        g = 0
        allNew = ""
        for candidate in fomalName[i]:
            p = 0
            temp = candidate.lower()
            tempArr = temp.split(' ')
            for t in tempArr:
                f = re.findall("{}".format(t), rawDf['raw'][i])
                if f:
                    p = p + 1
                    allNew = allNew + " {}".format(f[0])
                    g = g + p
            arr[temp] = p
            # # 조합해보기
            # if candidate == fomalName[i][-1]:
            #     print('hi')
            #     arr.append((g, allNew[1:]))
        final.append(arr)

        for c in final:
            blank = []
            li = list(c.items())
            li.sort(key= lambda x:x[1], reverse=True)
            a = 0
            for j in range(len(li)):
                # print(len(li), i, li[i])
                if j == 0:
                    a = li[j][1]
                    blank.append(li[j][0])
                    continue
                else:
                    if a > li[j][1]:
                        continue
                    elif a == li[j][1]:
                        blank.append(li[j][0])
        fomalName[i] = blank


# rawDf["productMapped"] = fomalName
# for i in rawDf['productMapped']:
#     print(i)