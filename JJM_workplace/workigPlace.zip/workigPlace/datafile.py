samsung_raw = """Samsung Galaxy S6
Samsung Galaxy S7
Samsung Galaxy S8
Samsung Galaxy S8 +
Samsung Galaxy S9
Samsung Galaxy S9 +
Samsung Galaxy S10
Samsung Galaxy S10 +
Samsung Galaxy S10 e
Samsung Galaxy S10 5G
Samsung Galaxy S20
Samsung Galaxy S20 +
Samsung Galaxy S20 Ultra 5G
Samsung Galaxy S20 + 5G
Samsung Galaxy S20 5G
Samsung Galaxy S20 Ultra LTE
Samsung Galaxy S20 FE
Samsung Galaxy S20 FE 5G
Samsung Galaxy S21 5G
Samsung Galaxy S21 + 5G
Samsung Galaxy S21 Ultra 5G
Samsung Galaxy S21 FE 5G
Samsung Galaxy S22 5G
Samsung Galaxy S22 + 5G
Samsung Galaxy S22 Ultra 5G
Samsung Galaxy S20 FE 2022
Samsung Galaxy A5 Duos
Samsung Galaxy A5 Duos
Samsung Galaxy A3
Samsung Galaxy A3 Duos
Samsung Galaxy A5
Samsung Galaxy A7
Samsung Galaxy A7 Duos
Samsung Galaxy A8
Samsung Galaxy A8 Duos
Samsung Galaxy A3 (2016)
Samsung Galaxy A5 (2016)
Samsung Galaxy A7 (2016)
Samsung Galaxy A9 (2016)
Samsung Galaxy A9 Pro (2016)
Samsung Galaxy A8 (2016)
Samsung Galaxy A3 (2017)
Samsung Galaxy A5 (2017)
Samsung Galaxy A7 (2017)
Samsung Galaxy A6 (2018)
Samsung Galaxy A6 + (2018)
Samsung Galaxy A8 Star 
Samsung Galaxy A9 Star
Samsung Galaxy A7 (2018)
Samsung Galaxy A9 (2018)
Samsung Galaxy A6 s
Samsung Galaxy A8 s
Samsung Galaxy A10
Samsung Galaxy A20
Samsung Galaxy A20 e
Samsung Galaxy A30
Samsung Galaxy A40
Samsung Galaxy A50
Samsung Galaxy A60
Samsung Galaxy A70
Samsung Galaxy A2 Core
Samsung Galaxy A80
Samsung Galaxy A10 e
Samsung Galaxy A10 s
Samsung Galaxy A50 s
Samsung Galaxy A30 s
Samsung Galaxy A90 5G
Samsung Galaxy A70 s
Samsung Galaxy A20 s
Samsung Galaxy A51
Samsung Galaxy A71
Samsung Galaxy A01
Samsung Galaxy A31
Samsung Galaxy A51 5G
Samsung Galaxy A41
Samsung Galaxy A Quantum
Samsung Galaxy A21 s
Samsung Galaxy A71 5G
Samsung Galaxy A21
Samsung Galaxy A01 Core
Samsung Galaxy A71 5G UW
Samsung Galaxy A51 5G UW
Samsung Galaxy A42 5G
Samsung Galaxy A12
Samsung Galaxy A02 s
Samsung Galaxy A32 5G
Samsung Galaxy A02
Samsung Galaxy A32
Samsung Galaxy A52 5G
Samsung Galaxy A52
Samsung Galaxy A72
Samsung Galaxy A22
Samsung Galaxy A22 5G
Samsung Galaxy A12 Nacho
Samsung Galaxy A03 s
Samsung Galaxy A52 s 5G
Samsung Galaxy A03 Core
Samsung Galaxy A03
Samsung Galaxy A13 5G
Samsung Galaxy A13
Samsung Galaxy A23
Samsung Galaxy A33 5G
Samsung Galaxy A53 5G
Samsung Galaxy A73 5G
Samsung Galaxy Note Pro 12.2
Samsung Galaxy Note 3 Neo
Samsung Galaxy Note 3 Neo Duos
Samsung Galaxy Note Pro 12.2 5G
Samsung Galaxy Note Pro 12.2 LTE
Samsung Galaxy Note 4
Samsung Galaxy Note 4 Duos
Samsung Galaxy Note Edge
Samsung Galaxy Note 5 Duos
Samsung Galaxy Note 5
Samsung Galaxy Note 7
Samsung Galaxy Note FE
Samsung Galaxy Note 8
Samsung Galaxy Note 9
Samsung Galaxy Note 10
Samsung Galaxy Note 10 5G
Samsung Galaxy Note 10 +
Samsung Galaxy Note 10 + 5G
Samsung Galaxy Note 10 Lite
Samsung Galaxy Note 20
Samsung Galaxy Note 20 5G
Samsung Galaxy Note 20 Ultra
Samsung Galaxy Note 20 Ultra 5G
Samsung Galaxy Tab Pro 8.4
Samsung Galaxy Tab 3 Lite 7.0
Samsung Galaxy Tab Pro 8.4 3G/LTE
Samsung Galaxy Tab Pro 10.1
Samsung Galaxy Tab Pro 10.1 LTE
Samsung Galaxy Tab Pro 12.2
Samsung Galaxy Tab Pro 12.2 3G
Samsung Galaxy Tab Pro 12.2 LTE
Samsung Galaxy Tab 3 Lite 7.0 3G
Samsung Galaxy Tab 4 7.0 LTE
Samsung Galaxy Tab 4 7.0 3G
Samsung Galaxy Tab 4 7.0
Samsung Galaxy Tab 4 10.1 LTE
Samsung Galaxy Tab 4 10.1 3G
Samsung Galaxy Tab 4 10.1
Samsung Galaxy Tab 4 8.0 LTE
Samsung Galaxy Tab 4 8.0 3G
Samsung Galaxy Tab 4 8.0
Samsung Galaxy Tab S 10.5
Samsung Galaxy Tab S 10.5 LTE
Samsung Galaxy Tab S 8.4
Samsung Galaxy Tab S 8.4 LTE
Samsung Galaxy Tab 3 Lite 7.0 VE
Samsung Galaxy Tab 3 V
Samsung Galaxy Tab A 8.0
Samsung Galaxy Tab A 9.7
Samsung Galaxy Tab A & S Pen
Samsung Galaxy Tab 4 10.1 (2015)
Samsung Galaxy Tab E 9.6
Samsung Galaxy Tab S2 8.0
Samsung Galaxy Tab S2 9.7
Samsung Galaxy Tab E 8.0
Samsung Galaxy Tab A 7.0 (2016)
Samsung Galaxy Tab A 10.1 (2016)
Samsung Galaxy Tab J
Samsung Galaxy Tab S3 9.7
Samsung Galaxy Tab A 8.0 (2017)
Samsung Galaxy Tab Active 2
Samsung Galaxy Tab A 10.5
Samsung Galaxy Tab S4 10.5
Samsung Galaxy Tab A 8.0 (2018)
Samsung Galaxy Tab Advanced2
Samsung Galaxy Tab A 8.0 & S Pen (2019)
Samsung Galaxy Tab A 10.1 (2019)
Samsung Galaxy Tab S5 e
Samsung Galaxy Tab A 8.0 (2019)
Samsung Galaxy Tab S6
Samsung Galaxy Tab Active Pro
Samsung Galaxy Tab S6 5G
Samsung Galaxy Tab A 8.4 (2020)
Samsung Galaxy Tab S6 Lite
Samsung Galaxy Tab S7
Samsung Galaxy Tab S7 +
Samsung Galaxy Tab A7 10.4 (2020)
Samsung Galaxy Tab Active3
Samsung Galaxy Tab S7 FE
Samsung Galaxy Tab A7 Lite
Samsung Galaxy Tab A8 10.5 (2021)
Samsung Galaxy Tab S8
Samsung Galaxy Tab S8 +
Samsung Galaxy Tab S8 Ultra
Samsung Galaxy Tab S6 Lite (2022)
Samsung Galaxy Fold
Samsung Galaxy Fold 5G
Samsung Galaxy Z Fold 2 5G
Samsung Galaxy Z Fold 3 5G
Samsung Galaxy Z Flip
Samsung Galaxy Z Flip 5G
Samsung Galaxy Z Flip 3 5G
Samsung Galaxy Z Fold 4
Samsung Galaxy Z Flip 4"""
iphone_raw = """
iPhone 6
iPhone 6 Plus
iPhone 6S
iPhone 6S Plus
iPhone SE (1st gen)
iPhone 7
iPhone 7 Plus
iPhone 8
iPhone 8 Plus
iPhone X
iPhone XR
iPhone XS
iPhone XS Max
iPhone 11
iPhone 11 Pro
iPhone 11 Pro Max
iPhone SE (2nd gen)
iPhone 12
iPhone 12 mini
iPhone 12 Pro
iPhone 12 Pro Max
iPhone 13
iPhone 13 mini
iPhone 13 Pro
iPhone 13 Pro Max
iPhone SE (3rd gen)
iPhone 14
iPhone 14 Plus
iPhone 14 Pro
iPhone 14 Pro Max"""
tecno_raw = """Spark Plus
Spark Pro
Phantom 6
Pop Lite
Pouvoir 2 Pro
Phantom 6 Plus
Pouvoir
Pop
Spark CM
Spark
Camon CM
F2 LTE
Camon CX Air
Camon CX
Pouvoir 2
Pop Pro
Pop s
Camon X
Spark 2
Camon X Pro
Phantom 8
Camon 11
F2"""

samsung = {
    "company": "Samsung",
    "model": ["Galaxy", "Galaxy Note", "Galaxy Tab", "Galaxy Z"],
    "series": ['A01', '8', 'A73', 'A80', 'S8', 'S7', 'A71', 'A51', 'A40', 'A70',
               'A6', 'A7', 'A41', 'Fold', 'A20', '7', '9', '10', 'A2', 'A3',
               'A60', 'S9', 'A33', 'S22', 'A5', 'A12', 'A8', 'Edge', '5',
               '3', 'Pro', 'A32', 'A03', 'S21', 'S6', 'A31', 'A02', 'A72', 'A23', '20',
               'A21', 'A90', '4', 'A52', 'A', 'S20', 'FE', 'A22', 'A13', 'Flip', 'A50',
               'A53', 'S10', 'A42', 'A9', 'A10', 'A30'],
    "version": ['10.1', 'FE', 'Ultra', 'V', 'Star', 'Star ', '8.0', '2', 'Core', '+',
                '7.0', '4', '10.5', '9.7', 'Neo', 'Quantum', '12.2', 'e', 'Lite 7.0',
                's', 'UW', '10.4', 'Lite', 'Nacho', '3', 'Pro', 'Duos', 'Neo Duos',
                'Lite 7.0 VE', '8.4']
}
apple = {
    "company": "Apple",
    "model": ["iPhone"],
    "series": ['7', 'SE', '6', '8', '11', '12', 'XS', '14', '6S', 'XR', '13', 'X'],
    "version": ['3rd gen', 'Pro', 'Max', '2nd gen', 'Pro Max', '1st gen', 'mini', 'Plus']
}
tecno = {
    "company": "Tecno",
    "model": ['Camon', 'Phantom', 'Pouvoir', 'Spark', 'Pop', 'F2'],
    "series": ['8', '2', 'CX', 'X', '11', '6', 'CM', 'LTE', '1'],
    "version": ['Lite', 'Air', 's', 'Pro', 'Plus']
}

samsung_variation = {
    "company": {
        "Samsung": ['Samsung', 'Sam', 'Sm', 'Smg', 'Ss', 'Ssg', 'Samsung', 'Sam', 'Sm', 'Smg', 'Ss', 'Ssg', 'samsung']},
    "model": {"Galaxy": ['Galaxy', 'Glxy', 'Gal', 'galaxy', 'Glx'],
              "Galaxy Note": ['Gal Not', 'Gal Note', 'GalNote', 'Nt', 'GalaxyNot', 'Galaxy Note', 'Galaxy Not', 'Glx Nte', 'GalNot', 'Glx Nt', 'GalaxyNote', 'Not', 'GlxNt', 'GlxNte', 'Nte', 'Note'],
              "Galaxy Tab": ['GlxT', 'Tab', 'Glx T', 'Tb', 'GalTab', 'Glx Tb', 'Gal Tab', 'Galaxy Tab', 'T', 'GlxTb', 'GalaxyTab'],
              "Galaxy Z": ['GalaxyZ', 'GalZ', 'Z', 'Glx Z', 'Gal Z', 'GlxZ', 'Galaxy Z']},
    "series": ['A01', '8', 'A73', 'A80', 'S8', 'S7', 'A71', 'A51', 'A40', 'A70',
               'A6', 'A7', 'A41', 'Fold', 'A20', '7', '9', '10', 'A2', 'A3',
               'A60', 'S9', 'A33', 'S22', 'A5', 'A12', 'A8', 'Edge', '5',
               '3', 'Pro', 'A32', 'A03', 'S21', 'S6', 'A31', 'A02', 'A72', 'A23', '20',
               'A21', 'A90', '4', 'A52', 'A', 'S20', 'FE', 'A22', 'A13', 'Flip', 'A50',
               'A53', 'S10', 'A42', 'A9', 'A10', 'A30'],
    "version": ['10.1', 'FE', 'Ultra', 'V', 'Star', 'Star ', '8.0', '2', 'Core', '+',
                '7.0', '4', '10.5', '9.7', 'Neo', 'Quantum', '12.2', 'e', 'Lite 7.0',
                's', 'UW', '10.4', 'Lite', 'Nacho', '3', 'Pro', 'Duos', 'Neo Duos',
                'Lite 7.0 VE', '8.4']
}

samsung_products = {
    'Samsung Galaxy Tab S7 FE': ['Tab S7 FE', 'Tab_S7_FE', 'TabS7FE'], 'Samsung Galaxy S10 5G': ['S10'],
    'Samsung Galaxy A8 Duos': ['A8Duos', 'A8_Duos', 'A8 Duos'],
    'Samsung Galaxy A01 Core': ['A01Core', 'A01 Core', 'A01_Core'],
    'Samsung Galaxy A8 Star ': ['A8_Star_', 'A8 Star ', 'A8Star'], 'Samsung Galaxy A6 +': ['A6 +', 'A6_+', 'A6+'],
    'Samsung Galaxy A30 s': ['A30 s', 'A30_s', 'A30s'],
    'Samsung Galaxy S20 Ultra LTE': ['S20 Ultra', 'S20Ultra', 'S20_Ultra'],
    'Samsung Galaxy Tab S 8.4 LTE': ['TabS8.4', 'Tab_S_8.4', 'Tab S 8.4'],
    'Samsung Galaxy Tab S8': ['Tab_S8', 'TabS8', 'Tab S8'], 'Samsung Galaxy S10 e': ['S10_e', 'S10e', 'S10 e'],
    'Samsung Galaxy A02 s': ['A02 s', 'A02_s', 'A02s'],
    'Samsung Galaxy Tab S6': ['Tab_S6', 'Tab S6', 'TabS6'], 'Samsung Galaxy A72': ['A72'],
    'Samsung Galaxy Tab S 8.4': ['TabS8.4', 'Tab_S_8.4', 'Tab S 8.4'],
    'Samsung Galaxy S22 + 5G': ['S22 +', 'S22+', 'S22_+'],
    'Samsung Galaxy Tab S2 9.7': ['Tab S2 9.7', 'Tab_S2_9.7', 'TabS29.7'], 'Samsung Galaxy S10': ['S10'],
    'Samsung Galaxy S9': ['S9'],
    'Samsung Galaxy Tab A 8.0': ['Tab A 8.0', 'Tab_A_8.0', 'TabA8.0'],
    'Samsung Galaxy Tab 4 10.1': ['Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1'],
    'Samsung Galaxy Z Flip 3 5G': ['Z_Flip_3', 'Z Flip 3', 'ZFlip3'],
    'Samsung Galaxy S9 +': ['S9_+', 'S9+', 'S9 +'], 'Samsung Galaxy A12 Nacho': ['A12Nacho', 'A12 Nacho', 'A12_Nacho'],
    'Samsung Galaxy Tab S4 10.5': ['TabS410.5', 'Tab_S4_10.5', 'Tab S4 10.5'],
    'Samsung Galaxy A8 s': ['A8_s', 'A8s', 'A8 s'], 'Samsung Galaxy Tab 3 V': ['Tab_3_V', 'Tab3V', 'Tab 3 V'],
    'Samsung Galaxy Tab Pro 12.2 3G': ['Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2'],
    'Samsung Galaxy A01': ['A01'], 'Samsung Galaxy Tab S8 Ultra': ['TabS8Ultra', 'Tab S8 Ultra', 'Tab_S8_Ultra'],
    'Samsung Galaxy Tab A8 10.5': ['Tab_A8_10.5', 'Tab A8 10.5', 'TabA810.5'],
    'Samsung Galaxy A10': ['A10'], 'Samsung Galaxy A6': ['A6'],
    'Samsung Galaxy Tab A 8.0 & S Pen': ['Tab A 8.0 & S Pen', 'TabA8.0&SPen', 'Tab_A_8.0_&_S_Pen'],
    'Samsung Galaxy Z Fold 4': ['Z_Fold_4', 'ZFold4', 'Z Fold 4'], 'Samsung Galaxy Fold': ['Fold'],
    'Samsung Galaxy A21': ['A21'], 'Samsung Galaxy S6': ['S6'],
    'Samsung Galaxy Tab 4 7.0': ['Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0'],
    'Samsung Galaxy Tab S6 5G': ['Tab_S6', 'Tab S6', 'TabS6'],
    'Samsung Galaxy Z Flip 5G': ['Z_Flip', 'Z Flip', 'ZFlip'],
    'Samsung Galaxy A50': ['A50'], 'Samsung Galaxy A40': ['A40'], 'Samsung Galaxy A32 5G': ['A32'],
    'Samsung Galaxy S20 + 5G': ['S20 +', 'S20+', 'S20_+'], 'Samsung Galaxy S20 FE': ['S20 FE', 'S20FE', 'S20_FE'],
    'Samsung Galaxy S22 5G': ['S22'], 'Samsung Galaxy A8': ['A8'],
    'Samsung Galaxy Tab A7 10.4': ['Tab A7 10.4', 'Tab_A7_10.4', 'TabA710.4'], 'Samsung Galaxy A12': ['A12'],
    'Samsung Galaxy A9 Pro': ['A9 Pro', 'A9Pro', 'A9_Pro'],
    'Samsung Galaxy Tab 4 7.0 LTE': ['Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0'], 'Samsung Galaxy Fold 5G': ['Fold'],
    'Samsung Galaxy A02': ['A02'],
    'Samsung Galaxy Note 20 Ultra 5G': ['Note20Ultra', 'Note 20 Ultra', 'Note_20_Ultra'],
    'Samsung Galaxy Z Flip 4': ['Z Flip 4', 'Z_Flip_4', 'ZFlip4'],
    'Samsung Galaxy Note Pro 12.2 5G': ['Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2'],
    'Samsung Galaxy Tab S7 +': ['Tab_S7_+', 'TabS7+', 'Tab S7 +'], 'Samsung Galaxy A03': ['A03'],
    'Samsung Galaxy Note Pro 12.2': ['Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2'],
    'Samsung Galaxy Tab S 10.5 LTE': ['Tab S 10.5', 'Tab_S_10.5', 'TabS10.5'], 'Samsung Galaxy A60': ['A60'],
    'Samsung Galaxy Tab Pro 8.4 3G/LTE': ['TabPro8.4', 'Tab Pro 8.4', 'Tab_Pro_8.4'],
    'Samsung Galaxy A7 Duos': ['A7_Duos', 'A7Duos', 'A7 Duos'],
    'Samsung Galaxy Note 10 + 5G': ['Note10+', 'Note_10_+', 'Note 10 +'],
    'Samsung Galaxy Note 20': ['Note 20', 'Note_20', 'Note20'],
    'Samsung Galaxy Tab A 9.7': ['TabA9.7', 'Tab A 9.7', 'Tab_A_9.7'],
    'Samsung Galaxy Tab A 7.0': ['TabA7.0', 'Tab A 7.0', 'Tab_A_7.0'],
    'Samsung Galaxy A20 s': ['A20s', 'A20_s', 'A20 s'], 'Samsung Galaxy Note 20 5G': ['Note 20', 'Note_20', 'Note20'],
    'Samsung Galaxy A33 5G': ['A33'],
    'Samsung Galaxy Tab A 10.1': ['Tab_A_10.1', 'TabA10.1', 'Tab A 10.1'],
    'Samsung Galaxy Note 10 5G': ['Note10', 'Note_10', 'Note 10'], 'Samsung Galaxy A52': ['A52'],
    'Samsung Galaxy A9 Star': ['A9_Star', 'A9 Star', 'A9Star'],
    'Samsung Galaxy Z Fold 3 5G': ['ZFold3', 'Z Fold 3', 'Z_Fold_3'],
    'Samsung Galaxy A21 s': ['A21_s', 'A21s', 'A21 s'],
    'Samsung Galaxy Tab 4 8.0': ['Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0'],
    'Samsung Galaxy Note 3 Neo': ['Note_3_Neo', 'Note 3 Neo', 'Note3Neo'],
    'Samsung Galaxy Tab A & S Pen': ['Tab A & S Pen', 'Tab_A_&_S_Pen', 'TabA&SPen'],
    'Samsung Galaxy A9': ['A9'], 'Samsung Galaxy Tab S6 Lite': ['TabS6Lite', 'Tab_S6_Lite', 'Tab S6 Lite'],
    'Samsung Galaxy Z Flip': ['Z_Flip', 'Z Flip', 'ZFlip'],
    'Samsung Galaxy A71 5G UW': ['A71UW', 'A71 UW', 'A71_UW'],
    'Samsung Galaxy Tab Active3': ['TabActive3', 'Tab_Active3', 'Tab Active3'],
    'Samsung Galaxy Tab S8 +': ['TabS8+', 'Tab S8 +', 'Tab_S8_+'],
    'Samsung Galaxy A32': ['A32'], 'Samsung Galaxy A22 5G': ['A22'], 'Samsung Galaxy A51': ['A51'],
    'Samsung Galaxy Tab Active Pro': ['Tab_Active_Pro', 'Tab Active Pro', 'TabActivePro'],
    'Samsung Galaxy Tab S3 9.7': ['Tab S3 9.7', 'Tab_S3_9.7', 'TabS39.7'],
    'Samsung Galaxy Tab E 8.0': ['TabE8.0', 'Tab E 8.0', 'Tab_E_8.0'], 'Samsung Galaxy A73 5G': ['A73'],
    'Samsung Galaxy Note 4 Duos': ['Note_4_Duos', 'Note4Duos', 'Note 4 Duos'],
    'Samsung Galaxy A50 s': ['A50s', 'A50_s', 'A50 s'],
    'Samsung Galaxy Note 5 Duos': ['Note5Duos', 'Note_5_Duos', 'Note 5 Duos'],
    'Samsung Galaxy Note FE': ['Note_FE', 'Note FE', 'NoteFE'],
    'Samsung Galaxy A03 Core': ['A03Core', 'A03_Core', 'A03 Core'], 'Samsung Galaxy A23': ['A23'],
    'Samsung Galaxy A6 s': ['A6_s', 'A6 s', 'A6s'],
    'Samsung Galaxy S8 +': ['S8+', 'S8_+', 'S8 +'], 'Samsung Galaxy A51 5G': ['A51'],
    'Samsung Galaxy S20 Ultra 5G': ['S20 Ultra', 'S20Ultra', 'S20_Ultra'],
    'Samsung Galaxy A3 Duos': ['A3 Duos', 'A3Duos', 'A3_Duos'],
    'Samsung Galaxy Tab 3 Lite 7.0 3G': ['Tab 3 Lite 7.0', 'Tab3Lite7.0', 'Tab_3_Lite_7.0'],
    'Samsung Galaxy Tab 4 8.0 3G': ['Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0'], 'Samsung Galaxy A13': ['A13'],
    'Samsung Galaxy S8': ['S8'], 'Samsung Galaxy Note 10 +': ['Note10+', 'Note_10_+', 'Note 10 +'],
    'Samsung Galaxy Note 20 Ultra': ['Note20Ultra', 'Note 20 Ultra', 'Note_20_Ultra'],
    'Samsung Galaxy A10 e': ['A10_e', 'A10 e', 'A10e'],
    'Samsung Galaxy Tab A7 Lite': ['Tab A7 Lite', 'Tab_A7_Lite', 'TabA7Lite'],
    'Samsung Galaxy S22 Ultra 5G': ['S22Ultra', 'S22 Ultra', 'S22_Ultra'],
    'Samsung Galaxy Note 3 Neo Duos': ['Note3NeoDuos', 'Note_3_Neo_Duos', 'Note 3 Neo Duos'],
    'Samsung Galaxy Note 5': ['Note_5', 'Note5', 'Note 5'],
    'Samsung Galaxy Note Pro 12.2 LTE': ['Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2'],
    'Samsung Galaxy A52 5G': ['A52'], 'Samsung Galaxy A53 5G': ['A53'],
    'Samsung Galaxy Note 4': ['Note_4', 'Note 4', 'Note4'], 'Samsung Galaxy S21 + 5G': ['S21 +', 'S21+', 'S21_+'],
    'Samsung Galaxy A41': ['A41'], 'Samsung Galaxy A2 Core': ['A2_Core', 'A2Core', 'A2 Core'],
    'Samsung Galaxy Note 9': ['Note 9', 'Note_9', 'Note9'],
    'Samsung Galaxy Note 10 Lite': ['Note_10_Lite', 'Note10Lite', 'Note 10 Lite'],
    'Samsung Galaxy Tab Pro 12.2 LTE': ['Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2'],
    'Samsung Galaxy Note Edge': ['Note_Edge', 'Note Edge', 'NoteEdge'],
    'Samsung Galaxy Note 10': ['Note10', 'Note_10', 'Note 10'],
    'Samsung Galaxy Tab 4 10.1 LTE': ['Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1'],
    'Samsung Galaxy Tab J': ['Tab J', 'Tab_J', 'TabJ'], 'Samsung Galaxy S21 5G': ['S21'],
    'Samsung Galaxy A13 5G': ['A13'], 'Samsung Galaxy A70': ['A70'],
    'Samsung Galaxy Tab 3 Lite 7.0 VE': ['Tab3Lite7.0VE', 'Tab 3 Lite 7.0 VE', 'Tab_3_Lite_7.0_VE'],
    'Samsung Galaxy Note 8': ['Note_8', 'Note 8', 'Note8'], 'Samsung Galaxy A71 5G': ['A71'],
    'Samsung Galaxy A10 s': ['A10s', 'A10_s', 'A10 s'], 'Samsung Galaxy A42 5G': ['A42'],
    'Samsung Galaxy A03 s': ['A03s', 'A03 s', 'A03_s'],
    'Samsung Galaxy Tab Pro 12.2': ['Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2'],
    'Samsung Galaxy Tab E 9.6': ['Tab E 9.6', 'Tab_E_9.6', 'TabE9.6'], 'Samsung Galaxy A22': ['A22'],
    'Samsung Galaxy S10 +': ['S10+', 'S10_+', 'S10 +'], 'Samsung Galaxy A5': ['A5'],
    'Samsung Galaxy Tab S5 e': ['TabS5e', 'Tab S5 e', 'Tab_S5_e'], 'Samsung Galaxy A90 5G': ['A90'],
    'Samsung Galaxy Tab Pro 8.4': ['TabPro8.4', 'Tab Pro 8.4', 'Tab_Pro_8.4'],
    'Samsung Galaxy Tab S 10.5': ['Tab S 10.5', 'Tab_S_10.5', 'TabS10.5'],
    'Samsung Galaxy Tab Advanced2': ['TabAdvanced2', 'Tab Advanced2', 'Tab_Advanced2'], 'Samsung Galaxy S7': ['S7'],
    'Samsung Galaxy Tab S2 8.0': ['Tab S2 8.0', 'TabS28.0', 'Tab_S2_8.0'],
    'Samsung Galaxy A20 e': ['A20e', 'A20_e', 'A20 e'],
    'Samsung Galaxy Tab Pro 10.1': ['Tab Pro 10.1', 'TabPro10.1', 'Tab_Pro_10.1'],
    'Samsung Galaxy A70 s': ['A70_s', 'A70 s', 'A70s'], 'Samsung Galaxy A20': ['A20'], 'Samsung Galaxy A31': ['A31'],
    'Samsung Galaxy Tab Pro 10.1 LTE': ['Tab Pro 10.1', 'TabPro10.1', 'Tab_Pro_10.1'],
    'Samsung Galaxy S20 FE 5G': ['S20 FE', 'S20FE', 'S20_FE'],
    'Samsung Galaxy A51 5G UW': ['A51_UW', 'A51 UW', 'A51UW'],
    'Samsung Galaxy Z Fold 2 5G': ['Z Fold 2', 'ZFold2', 'Z_Fold_2'],
    'Samsung Galaxy Tab 4 8.0 LTE': ['Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0'],
    'Samsung Galaxy Tab S7': ['Tab_S7', 'TabS7', 'Tab S7'],
    'Samsung Galaxy S21 Ultra 5G': ['S21 Ultra', 'S21Ultra', 'S21_Ultra'],
    'Samsung Galaxy Note 7': ['Note7', 'Note_7', 'Note 7'],
    'Samsung Galaxy Tab A 8.4': ['TabA8.4', 'Tab A 8.4', 'Tab_A_8.4'], 'Samsung Galaxy A71': ['A71'],
    'Samsung Galaxy A5 Duos': ['A5 Duos', 'A5Duos', 'A5_Duos'],
    'Samsung Galaxy A3': ['A3'], 'Samsung Galaxy S21 FE 5G': ['S21 FE', 'S21_FE', 'S21FE'],
    'Samsung Galaxy Tab A 10.5': ['TabA10.5', 'Tab_A_10.5', 'Tab A 10.5'], 'Samsung Galaxy S20': ['S20'],
    'Samsung Galaxy A30': ['A30'], 'Samsung Galaxy Tab 4 10.1 3G': ['Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1'],
    'Samsung Galaxy Tab 4 7.0 3G': ['Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0'],
    'Samsung Galaxy A52 s 5G': ['A52_s', 'A52 s', 'A52s'],
    'Samsung Galaxy A Quantum': ['A_Quantum', 'A Quantum', 'AQuantum'], 'Samsung Galaxy S20 5G': ['S20'],
    'Samsung Galaxy Tab 3 Lite 7.0': ['Tab 3 Lite 7.0', 'Tab3Lite7.0', 'Tab_3_Lite_7.0'],
    'Samsung Galaxy Tab Active 2': ['TabActive2', 'Tab_Active_2', 'Tab Active 2'], 'Samsung Galaxy A7': ['A7'],
    'Samsung Galaxy A80': ['A80'], 'Samsung Galaxy S20 +': ['S20 +', 'S20+', 'S20_+'],
}
iPhone_products = {
    'iPhone 7': ['7'], 'iPhone 14 Plus': ['14_+', '14_Plus', '14+', '14 +', '14Plus', '14 Plus'],
    'iPhone 11 Pro Max': ['11 Pro Max', '11ProMax', '11_Pro_Max'], 'iPhone 6S Plus': ['6S +', '6S Plus', '6S_Plus', '6S+', '6SPlus', '6S_+'],
    'iPhone 14 Pro': ['14_Pro', '14Pro', '14 Pro'], 'iPhone 6S': ['6S'], 'iPhone XS': ['XS'], 'iPhone 8': ['8'], 'iPhone 8 Plus': ['8 +', '8+', '8_+', '8 Plus', '8Plus', '8_Plus'],
    'iPhone SE (2nd gen)': ['SE 2 gen', 'SE_2nd_gen', 'SE2gen', 'SE 2nd gen', 'SE_2_gen', 'SE2ndgen', 'SE 2', 'SE2'], 'iPhone 11': ['11'],
    'iPhone SE (1st gen)': ['SE_1st_gen', 'SE1stgen', 'SE 1st gen', 'SE1gen', 'SE_1_gen', 'SE 1 gen', 'SE', 'SE 1', 'SE1'], 'iPhone 6': ['6'], 'iPhone X': ['X'], 'iPhone 11 Pro': ['11Pro', '11_Pro', '11 Pro'],
    'iPhone SE (3rd gen)': ['SE_3_gen', 'SE_3rd_gen', 'SE 3rd gen', 'SE3rdgen', 'SE 3 gen', 'SE3gen', 'SE 3', 'SE3'], 'iPhone XR': ['XR'], 'iPhone 13 mini': ['13 mini', '13_mini', '13mini'],
    'iPhone 12 Pro Max': ['12_Pro_Max', '12ProMax', '12 Pro Max'], 'iPhone 12': ['12'], 'iPhone XS Max': ['XSMax', 'XS_Max', 'XS Max'], 'iPhone 12 Pro': ['12Pro', '12_Pro', '12 Pro'], 'iPhone 13': ['13'],
    'iPhone 6 Plus': ['6Plus', '6+', '6 +', '6_+', '6_Plus', '6 Plus'], 'iPhone 14': ['14'], 'iPhone 12 mini': ['12mini', '12_mini', '12 mini'], 'iPhone 7 Plus': ['7 +', '7+', '7_Plus', '7_+', '7Plus', '7 Plus'],
    'iPhone 14 Pro Max': ['14 Pro Max', '14_Pro_Max', '14ProMax'], 'iPhone 13 Pro': ['13_Pro', '13Pro', '13 Pro'], 'iPhone 13 Pro Max': ['13 Pro Max', '13ProMax', '13_Pro_Max']
}
tecno_products = {
    'Tecno Pouvoir 2 Pro': ['Pouvoir2Pro', 'Pouvoir 2 Pro', 'Pouvoir_2_Pro'], 'Tecno Pop Pro': ['PopPro', 'Pop Pro', 'Pop_Pro'], 'Tecno Camon CM': ['CamonCM', 'Camon_CM', 'Camon CM'],
    'Tecno Camon CX Air': ['Camon CX Air', 'CamonCXAir', 'Camon_CX_Air'], 'Tecno Pop': ['Pop'], 'Tecno F2 LTE': ['F2_LTE', 'F2 LTE', 'F2LTE'],
    'Tecno Phantom 8': ['Phantom_8', 'Phantom 8', 'Phantom8'], 'Tecno Pop Lite': ['PopLite', 'Pop_Lite', 'Pop Lite'],
    'Tecno Camon X': ['CamonX', 'Camon_X', 'Camon X'], 'Tecno Phantom 6 Plus': ['Phantom6+', 'Phantom_6_Plus', 'Phantom 6 +', 'Phantom 6 Plus', 'Phantom6Plus', 'Phantom_6_+'],
    'Tecno Camon 11': ['Camon_11', 'Camon 11', 'Camon11'], 'Tecno Spark Pro': ['Spark Pro', 'Spark_Pro', 'SparkPro'],
    'Tecno Spark 2': ['Spark_2', 'Spark 2', 'Spark2'], 'Tecno Phantom 6': ['Phantom6', 'Phantom_6', 'Phantom 6'],
    'Tecno Camon CX': ['Camon_CX', 'Camon CX', 'CamonCX'], 'Tecno Pop s': ['Pop_s', 'Pop s', 'Pops'], 'Tecno Pouvoir': ['Pouvoir'],
    'Tecno Spark Plus': ['Spark_Plus', 'SparkPlus', 'Spark_+', 'Spark +', 'Spark Plus', 'Spark+'], 'Tecno Spark': ['Spark'], 'Tecno F2': ['F2'],
    'Tecno Camon X Pro': ['Camon X Pro', 'CamonXPro', 'Camon_X_Pro'], 'Tecno Spark CM': ['Spark CM', 'Spark_CM', 'SparkCM'],
    'Tecno Pouvoir 2': ['Pouvoir_2', 'Pouvoir 2', 'Pouvoir2']
}

tag = {
    "company": ["Samsung", "Apple", "Tecno"],
    "brand": ["iPhone", "Galaxy"],
    "model": ['Tab S7 FE', 'Tab_S7_FE', 'TabS7FE', 'S10', 'A8Duos', 'A8_Duos', 'A8 Duos', 'A01Core', 'A01 Core', 'A01_Core', 'A8_Star_',
              'A8 Star ', 'A8Star', 'A6 +', 'A6_+', 'A6+', 'A30 s', 'A30_s', 'A30s', 'S20 Ultra', 'S20Ultra', 'S20_Ultra', 'TabS8.4',
              'Tab_S_8.4', 'Tab S 8.4', 'Tab_S8', 'TabS8', 'Tab S8', 'S10_e', 'S10e', 'S10 e', 'A02 s', 'A02_s', 'A02s', 'Tab_S6', 'Tab S6',
              'TabS6', 'A72', 'TabS8.4', 'Tab_S_8.4', 'Tab S 8.4', 'S22 +', 'S22+', 'S22_+', 'Tab S2 9.7', 'Tab_S2_9.7', 'TabS29.7', 'S10',
              'S9', 'Tab A 8.0', 'Tab_A_8.0', 'TabA8.0', 'Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1', 'Z_Flip_3', 'Z Flip 3', 'ZFlip3', 'S9_+',
              'S9+', 'S9 +', 'A12Nacho', 'A12 Nacho', 'A12_Nacho', 'TabS410.5', 'Tab_S4_10.5', 'Tab S4 10.5', 'A8_s', 'A8s', 'A8 s', 'Tab_3_V',
              'Tab3V', 'Tab 3 V', 'Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2', 'A01', 'TabS8Ultra', 'Tab S8 Ultra', 'Tab_S8_Ultra', 'Tab_A8_10.5',
              'Tab A8 10.5', 'TabA810.5', 'A10', 'A6', 'Tab A 8.0 & S Pen', 'TabA8.0&SPen', 'Tab_A_8.0_&_S_Pen', 'Z_Fold_4', 'ZFold4', 'Z Fold 4',
              'Fold', 'A21', 'S6', 'Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0', 'Tab_S6', 'Tab S6', 'TabS6', 'Z_Flip', 'Z Flip', 'ZFlip', 'A50', 'A40', 'A32',
              'S20 +', 'S20+', 'S20_+', 'S20 FE', 'S20FE', 'S20_FE', 'S22', 'A8', 'Tab A7 10.4', 'Tab_A7_10.4', 'TabA710.4', 'A12', 'A9 Pro', 'A9Pro',
              'A9_Pro', 'Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0', 'Fold', 'A02', 'Note20Ultra', 'Note 20 Ultra', 'Note_20_Ultra', 'Z Flip 4', 'Z_Flip_4', 'ZFlip4',
              'Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2', 'Tab_S7_+', 'TabS7+', 'Tab S7 +', 'A03', 'Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2',
              'Tab S 10.5', 'Tab_S_10.5', 'TabS10.5', 'A60', 'TabPro8.4', 'Tab Pro 8.4', 'Tab_Pro_8.4', 'A7_Duos', 'A7Duos', 'A7 Duos', 'Note10+', 'Note_10_+',
              'Note 10 +', 'Note 20', 'Note_20', 'Note20', 'TabA9.7', 'Tab A 9.7', 'Tab_A_9.7', 'TabA7.0', 'Tab A 7.0', 'Tab_A_7.0', 'A20s', 'A20_s', 'A20 s',
              'Note 20', 'Note_20', 'Note20', 'A33', 'Tab_A_10.1', 'TabA10.1', 'Tab A 10.1', 'Note10', 'Note_10', 'Note 10', 'A52', 'A9_Star', 'A9 Star',
              'A9Star', 'ZFold3', 'Z Fold 3', 'Z_Fold_3', 'A21_s', 'A21s', 'A21 s', 'Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0', 'Note_3_Neo', 'Note 3 Neo', 'Note3Neo',
              'Tab A & S Pen', 'Tab_A_&_S_Pen', 'TabA&SPen', 'A9', 'TabS6Lite', 'Tab_S6_Lite', 'Tab S6 Lite', 'Z_Flip', 'Z Flip', 'ZFlip', 'A71UW', 'A71 UW',
              'A71_UW', 'TabActive3', 'Tab_Active3', 'Tab Active3', 'TabS8+', 'Tab S8 +', 'Tab_S8_+', 'A32', 'A22', 'A51', 'Tab_Active_Pro', 'Tab Active Pro',
              'TabActivePro', 'Tab S3 9.7', 'Tab_S3_9.7', 'TabS39.7', 'TabE8.0', 'Tab E 8.0', 'Tab_E_8.0', 'A73', 'Note_4_Duos', 'Note4Duos', 'Note 4 Duos',
              'A50s', 'A50_s', 'A50 s', 'Note5Duos', 'Note_5_Duos', 'Note 5 Duos', 'Note_FE', 'Note FE', 'NoteFE', 'A03Core', 'A03_Core', 'A03 Core', 'A23',
              'A6_s', 'A6 s', 'A6s', 'S8+', 'S8_+', 'S8 +', 'A51', 'S20 Ultra', 'S20Ultra', 'S20_Ultra', 'A3 Duos', 'A3Duos', 'A3_Duos', 'Tab 3 Lite 7.0',
              'Tab3Lite7.0', 'Tab_3_Lite_7.0', 'Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0', 'A13', 'S8', 'Note10+', 'Note_10_+', 'Note 10 +', 'Note20Ultra', 'Note 20 Ultra',
              'Note_20_Ultra', 'A10_e', 'A10 e', 'A10e', 'Tab A7 Lite', 'Tab_A7_Lite', 'TabA7Lite', 'S22Ultra', 'S22 Ultra', 'S22_Ultra', 'Note3NeoDuos', 'Note_3_Neo_Duos',
              'Note 3 Neo Duos', 'Note_5', 'Note5', 'Note 5', 'Note Pro 12.2', 'Note_Pro_12.2', 'NotePro12.2', 'A52', 'A53', 'Note_4', 'Note 4', 'Note4', 'S21 +', 'S21+', 'S21_+',
              'A41', 'A2_Core', 'A2Core', 'A2 Core', 'Note 9', 'Note_9', 'Note9', 'Note_10_Lite', 'Note10Lite', 'Note 10 Lite', 'Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2',
              'Note_Edge', 'Note Edge', 'NoteEdge', 'Note10', 'Note_10', 'Note 10', 'Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1', 'Tab J', 'Tab_J', 'TabJ', 'S21', 'A13', 'A70',
              'Tab3Lite7.0VE', 'Tab 3 Lite 7.0 VE', 'Tab_3_Lite_7.0_VE', 'Note_8', 'Note 8', 'Note8', 'A71', 'A10s', 'A10_s', 'A10 s', 'A42', 'A03s', 'A03 s', 'A03_s',
              'Tab_Pro_12.2', 'TabPro12.2', 'Tab Pro 12.2', 'Tab E 9.6', 'Tab_E_9.6', 'TabE9.6', 'A22', 'S10+', 'S10_+', 'S10 +', 'A5', 'TabS5e', 'Tab S5 e', 'Tab_S5_e',
              'A90', 'TabPro8.4', 'Tab Pro 8.4', 'Tab_Pro_8.4', 'Tab S 10.5', 'Tab_S_10.5', 'TabS10.5', 'TabAdvanced2', 'Tab Advanced2', 'Tab_Advanced2', 'S7', 'Tab S2 8.0',
              'TabS28.0', 'Tab_S2_8.0', 'A20e', 'A20_e', 'A20 e', 'Tab Pro 10.1', 'TabPro10.1', 'Tab_Pro_10.1', 'A70_s', 'A70 s', 'A70s', 'A20', 'A31', 'Tab Pro 10.1', 'TabPro10.1',
              'Tab_Pro_10.1', 'S20 FE', 'S20FE', 'S20_FE', 'A51_UW', 'A51 UW', 'A51UW', 'Z Fold 2', 'ZFold2', 'Z_Fold_2', 'Tab 4 8.0', 'Tab_4_8.0', 'Tab48.0', 'Tab_S7', 'TabS7',
              'Tab S7', 'S21 Ultra', 'S21Ultra', 'S21_Ultra', 'Note7', 'Note_7', 'Note 7', 'TabA8.4', 'Tab A 8.4', 'Tab_A_8.4', 'A71', 'A5 Duos', 'A5Duos', 'A5_Duos', 'A3', 'S21 FE',
              'S21_FE', 'S21FE', 'TabA10.5', 'Tab_A_10.5', 'Tab A 10.5', 'S20', 'A30', 'Tab410.1', 'Tab 4 10.1', 'Tab_4_10.1', 'Tab_4_7.0', 'Tab 4 7.0', 'Tab47.0', 'A52_s', 'A52 s',
              'A52s', 'A_Quantum', 'A Quantum', 'AQuantum', 'S20', 'Tab 3 Lite 7.0', 'Tab3Lite7.0', 'Tab_3_Lite_7.0', 'TabActive2', 'Tab_Active_2', 'Tab Active 2', 'A7', 'A80',
              'S20 +', 'S20+', 'S20_+', '7', '14_+', '14_Plus', '14+', '14 +', '14Plus', '14 Plus', '11 Pro Max', '11ProMax', '11_Pro_Max', '6S +', '6S Plus', '6S_Plus', '6S+',
              '6SPlus', '6S_+', '14_Pro', '14Pro', '14 Pro', '6S', 'XS', '8', '8 +', '8+', '8_+', '8 Plus', '8Plus', '8_Plus', 'SE 2 gen', 'SE_2nd_gen', 'SE2gen', 'SE 2nd gen',
              'SE_2_gen', 'SE2ndgen', 'SE 2', 'SE2', '11', 'SE_1st_gen', 'SE1stgen', 'SE 1st gen', 'SE1gen', 'SE_1_gen', 'SE 1 gen', 'SE', 'SE 1', 'SE1', '6', 'X', '11Pro',
              '11_Pro', '11 Pro', 'SE_3_gen', 'SE_3rd_gen', 'SE 3rd gen', 'SE3rdgen', 'SE 3 gen', 'SE3gen', 'SE 3', 'SE3', 'XR', '13 mini', '13_mini', '13mini', '12_Pro_Max',
              '12ProMax', '12 Pro Max', '12', 'XSMax', 'XS_Max', 'XS Max', '12Pro', '12_Pro', '12 Pro', '13', '6Plus', '6+', '6 +', '6_+', '6_Plus', '6 Plus', '14', '12mini',
              '12_mini', '12 mini', '7 +', '7+', '7_Plus', '7_+', '7Plus', '7 Plus', '14 Pro Max', '14_Pro_Max', '14ProMax', '13_Pro', '13Pro', '13 Pro', '13 Pro Max',
              '13ProMax', '13_Pro_Max', 'Pouvoir2Pro', 'Pouvoir 2 Pro', 'Pouvoir_2_Pro', 'PopPro', 'Pop Pro', 'Pop_Pro', 'CamonCM', 'Camon_CM', 'Camon CM', 'Camon CX Air',
              'CamonCXAir', 'Camon_CX_Air', 'Pop', 'F2_LTE', 'F2 LTE', 'F2LTE', 'Phantom_8', 'Phantom 8', 'Phantom8', 'PopLite', 'Pop_Lite', 'Pop Lite', 'CamonX', 'Camon_X',
              'Camon X', 'Phantom6+', 'Phantom_6_Plus', 'Phantom 6 +', 'Phantom 6 Plus', 'Phantom6Plus', 'Phantom_6_+', 'Camon_11', 'Camon 11', 'Camon11', 'Spark Pro',
              'Spark_Pro', 'SparkPro', 'Spark_2', 'Spark 2', 'Spark2', 'Phantom6', 'Phantom_6', 'Phantom 6', 'Camon_CX', 'Camon CX', 'CamonCX', 'Pop_s', 'Pop s', 'Pops',
              'Pouvoir', 'Spark_Plus', 'SparkPlus', 'Spark_+', 'Spark +', 'Spark Plus', 'Spark+', 'Spark', 'F2', 'Camon X Pro', 'CamonXPro', 'Camon_X_Pro', 'Spark CM',
              'Spark_CM', 'SparkCM', 'Pouvoir_2', 'Pouvoir 2', 'Pouvoir2'],
    "version": ['+', 'plus', '1', 'pro']
}
allproducts = {'Samsung Galaxy Tab S7 FE': ['tab s7 fe', 'tab_s7_fe', 'tabs7fe'], 'Samsung Galaxy S10 5G': ['s10'], 'Samsung Galaxy A8 Duos': ['a8duos', 'a8_duos', 'a8 duos'], 'Samsung Galaxy A01 Core': ['a01core', 'a01 core', 'a01_core'], 'Samsung Galaxy A8 Star ': ['a8_star_', 'a8 star ', 'a8star'], 'Samsung Galaxy A6 +': ['a6 +', 'a6_+', 'a6+'], 'Samsung Galaxy A30 s': ['a30 s', 'a30_s', 'a30s'], 'Samsung Galaxy S20 Ultra LTE': ['s20 ultra', 's20ultra', 's20_ultra'], 'Samsung Galaxy Tab S 8.4 LTE': ['tabs8.4', 'tab_s_8.4', 'tab s 8.4'], 'Samsung Galaxy Tab S8': ['tab_s8', 'tabs8', 'tab s8'], 'Samsung Galaxy S10 e': ['s10_e', 's10e', 's10 e'], 'Samsung Galaxy A02 s': ['a02 s', 'a02_s', 'a02s'], 'Samsung Galaxy Tab S6': ['tab_s6', 'tab s6', 'tabs6'], 'Samsung Galaxy A72': ['a72'], 'Samsung Galaxy Tab S 8.4': ['tabs8.4', 'tab_s_8.4', 'tab s 8.4'], 'Samsung Galaxy S22 + 5G': ['s22 +', 's22+', 's22_+'], 'Samsung Galaxy Tab S2 9.7': ['tab s2 9.7', 'tab_s2_9.7', 'tabs29.7'], 'Samsung Galaxy S10': ['s10'], 'Samsung Galaxy S9': ['s9'], 'Samsung Galaxy Tab A 8.0': ['tab a 8.0', 'tab_a_8.0', 'taba8.0'], 'Samsung Galaxy Tab 4 10.1': ['tab410.1', 'tab 4 10.1', 'tab_4_10.1'], 'Samsung Galaxy Z Flip 3 5G': ['z_flip_3', 'z flip 3', 'zflip3'], 'Samsung Galaxy S9 +': ['s9_+', 's9+', 's9 +'], 'Samsung Galaxy A12 Nacho': ['a12nacho', 'a12 nacho', 'a12_nacho'], 'Samsung Galaxy Tab S4 10.5': ['tabs410.5', 'tab_s4_10.5', 'tab s4 10.5'], 'Samsung Galaxy A8 s': ['a8_s', 'a8s', 'a8 s'], 'Samsung Galaxy Tab 3 V': ['tab_3_v', 'tab3v', 'tab 3 v'], 'Samsung Galaxy Tab Pro 12.2 3G': ['tab_pro_12.2', 'tabpro12.2', 'tab pro 12.2'], 'Samsung Galaxy A01': ['a01'], 'Samsung Galaxy Tab S8 Ultra': ['tabs8ultra', 'tab s8 ultra', 'tab_s8_ultra'], 'Samsung Galaxy Tab A8 10.5': ['tab_a8_10.5', 'tab a8 10.5', 'taba810.5'], 'Samsung Galaxy A10': ['a10'], 'Samsung Galaxy A6': ['a6'], 'Samsung Galaxy Tab A 8.0 & S Pen': ['tab a 8.0 & s pen', 'taba8.0&spen', 'tab_a_8.0_&_s_pen'], 'Samsung Galaxy Z Fold 4': ['z_fold_4', 'zfold4', 'z fold 4'], 'Samsung Galaxy Fold': ['fold'], 'Samsung Galaxy A21': ['a21'], 'Samsung Galaxy S6': ['s6'], 'Samsung Galaxy Tab 4 7.0': ['tab_4_7.0', 'tab 4 7.0', 'tab47.0'], 'Samsung Galaxy Tab S6 5G': ['tab_s6', 'tab s6', 'tabs6'], 'Samsung Galaxy Z Flip 5G': ['z_flip', 'z flip', 'zflip'], 'Samsung Galaxy A50': ['a50'], 'Samsung Galaxy A40': ['a40'], 'Samsung Galaxy A32 5G': ['a32'], 'Samsung Galaxy S20 + 5G': ['s20 +', 's20+', 's20_+'], 'Samsung Galaxy S20 FE': ['s20 fe', 's20fe', 's20_fe'], 'Samsung Galaxy S22 5G': ['s22'], 'Samsung Galaxy A8': ['a8'], 'Samsung Galaxy Tab A7 10.4': ['tab a7 10.4', 'tab_a7_10.4', 'taba710.4'], 'Samsung Galaxy A12': ['a12'], 'Samsung Galaxy A9 Pro': ['a9 pro', 'a9pro', 'a9_pro'], 'Samsung Galaxy Tab 4 7.0 LTE': ['tab_4_7.0', 'tab 4 7.0', 'tab47.0'], 'Samsung Galaxy Fold 5G': ['fold'], 'Samsung Galaxy A02': ['a02'], 'Samsung Galaxy Note 20 Ultra 5G': ['note20ultra', 'note 20 ultra', 'note_20_ultra'], 'Samsung Galaxy Z Flip 4': ['z flip 4', 'z_flip_4', 'zflip4'], 'Samsung Galaxy Note Pro 12.2 5G': ['note pro 12.2', 'note_pro_12.2', 'notepro12.2'], 'Samsung Galaxy Tab S7 +': ['tab_s7_+', 'tabs7+', 'tab s7 +'], 'Samsung Galaxy A03': ['a03'], 'Samsung Galaxy Note Pro 12.2': ['note pro 12.2', 'note_pro_12.2', 'notepro12.2'], 'Samsung Galaxy Tab S 10.5 LTE': ['tab s 10.5', 'tab_s_10.5', 'tabs10.5'], 'Samsung Galaxy A60': ['a60'], 'Samsung Galaxy Tab Pro 8.4 3G/LTE': ['tabpro8.4', 'tab pro 8.4', 'tab_pro_8.4'], 'Samsung Galaxy A7 Duos': ['a7_duos', 'a7duos', 'a7 duos'], 'Samsung Galaxy Note 10 + 5G': ['note10+', 'note_10_+', 'note 10 +'], 'Samsung Galaxy Note 20': ['note 20', 'note_20', 'note20'], 'Samsung Galaxy Tab A 9.7': ['taba9.7', 'tab a 9.7', 'tab_a_9.7'], 'Samsung Galaxy Tab A 7.0': ['taba7.0', 'tab a 7.0', 'tab_a_7.0'], 'Samsung Galaxy A20 s': ['a20s', 'a20_s', 'a20 s'], 'Samsung Galaxy Note 20 5G': ['note 20', 'note_20', 'note20'], 'Samsung Galaxy A33 5G': ['a33'], 'Samsung Galaxy Tab A 10.1': ['tab_a_10.1', 'taba10.1', 'tab a 10.1'], 'Samsung Galaxy Note 10 5G': ['note10', 'note_10', 'note 10'], 'Samsung Galaxy A52': ['a52'], 'Samsung Galaxy A9 Star': ['a9_star', 'a9 star', 'a9star'], 'Samsung Galaxy Z Fold 3 5G': ['zfold3', 'z fold 3', 'z_fold_3'], 'Samsung Galaxy A21 s': ['a21_s', 'a21s', 'a21 s'], 'Samsung Galaxy Tab 4 8.0': ['tab 4 8.0', 'tab_4_8.0', 'tab48.0'], 'Samsung Galaxy Note 3 Neo': ['note_3_neo', 'note 3 neo', 'note3neo'], 'Samsung Galaxy Tab A & S Pen': ['tab a & s pen', 'tab_a_&_s_pen', 'taba&spen'], 'Samsung Galaxy A9': ['a9'], 'Samsung Galaxy Tab S6 Lite': ['tabs6lite', 'tab_s6_lite', 'tab s6 lite'], 'Samsung Galaxy Z Flip': ['z_flip', 'z flip', 'zflip'], 'Samsung Galaxy A71 5G UW': ['a71uw', 'a71 uw', 'a71_uw'], 'Samsung Galaxy Tab Active3': ['tabactive3', 'tab_active3', 'tab active3'], 'Samsung Galaxy Tab S8 +': ['tabs8+', 'tab s8 +', 'tab_s8_+'], 'Samsung Galaxy A32': ['a32'], 'Samsung Galaxy A22 5G': ['a22'], 'Samsung Galaxy A51': ['a51'], 'Samsung Galaxy Tab Active Pro': ['tab_active_pro', 'tab active pro', 'tabactivepro'], 'Samsung Galaxy Tab S3 9.7': ['tab s3 9.7', 'tab_s3_9.7', 'tabs39.7'], 'Samsung Galaxy Tab E 8.0': ['tabe8.0', 'tab e 8.0', 'tab_e_8.0'], 'Samsung Galaxy A73 5G': ['a73'], 'Samsung Galaxy Note 4 Duos': ['note_4_duos', 'note4duos', 'note 4 duos'], 'Samsung Galaxy A50 s': ['a50s', 'a50_s', 'a50 s'], 'Samsung Galaxy Note 5 Duos': ['note5duos', 'note_5_duos', 'note 5 duos'], 'Samsung Galaxy Note FE': ['note_fe', 'note fe', 'notefe'], 'Samsung Galaxy A03 Core': ['a03core', 'a03_core', 'a03 core'], 'Samsung Galaxy A23': ['a23'], 'Samsung Galaxy A6 s': ['a6_s', 'a6 s', 'a6s'], 'Samsung Galaxy S8 +': ['s8+', 's8_+', 's8 +'], 'Samsung Galaxy A51 5G': ['a51'], 'Samsung Galaxy S20 Ultra 5G': ['s20 ultra', 's20ultra', 's20_ultra'], 'Samsung Galaxy A3 Duos': ['a3 duos', 'a3duos', 'a3_duos'], 'Samsung Galaxy Tab 3 Lite 7.0 3G': ['tab 3 lite 7.0', 'tab3lite7.0', 'tab_3_lite_7.0'], 'Samsung Galaxy Tab 4 8.0 3G': ['tab 4 8.0', 'tab_4_8.0', 'tab48.0'], 'Samsung Galaxy A13': ['a13'], 'Samsung Galaxy S8': ['s8'], 'Samsung Galaxy Note 10 +': ['note10+', 'note_10_+', 'note 10 +'], 'Samsung Galaxy Note 20 Ultra': ['note20ultra', 'note 20 ultra', 'note_20_ultra'], 'Samsung Galaxy A10 e': ['a10_e', 'a10 e', 'a10e'], 'Samsung Galaxy Tab A7 Lite': ['tab a7 lite', 'tab_a7_lite', 'taba7lite'], 'Samsung Galaxy S22 Ultra 5G': ['s22ultra', 's22 ultra', 's22_ultra'], 'Samsung Galaxy Note 3 Neo Duos': ['note3neoduos', 'note_3_neo_duos', 'note 3 neo duos'], 'Samsung Galaxy Note 5': ['note_5', 'note5', 'note 5'], 'Samsung Galaxy Note Pro 12.2 LTE': ['note pro 12.2', 'note_pro_12.2', 'notepro12.2'], 'Samsung Galaxy A52 5G': ['a52'], 'Samsung Galaxy A53 5G': ['a53'], 'Samsung Galaxy Note 4': ['note_4', 'note 4', 'note4'], 'Samsung Galaxy S21 + 5G': ['s21 +', 's21+', 's21_+'], 'Samsung Galaxy A41': ['a41'], 'Samsung Galaxy A2 Core': ['a2_core', 'a2core', 'a2 core'], 'Samsung Galaxy Note 9': ['note 9', 'note_9', 'note9'], 'Samsung Galaxy Note 10 Lite': ['note_10_lite', 'note10lite', 'note 10 lite'], 'Samsung Galaxy Tab Pro 12.2 LTE': ['tab_pro_12.2', 'tabpro12.2', 'tab pro 12.2'], 'Samsung Galaxy Note Edge': ['note_edge', 'note edge', 'noteedge'], 'Samsung Galaxy Note 10': ['note10', 'note_10', 'note 10'], 'Samsung Galaxy Tab 4 10.1 LTE': ['tab410.1', 'tab 4 10.1', 'tab_4_10.1'], 'Samsung Galaxy Tab J': ['tab j', 'tab_j', 'tabj'], 'Samsung Galaxy S21 5G': ['s21'], 'Samsung Galaxy A13 5G': ['a13'], 'Samsung Galaxy A70': ['a70'], 'Samsung Galaxy Tab 3 Lite 7.0 VE': ['tab3lite7.0ve', 'tab 3 lite 7.0 ve', 'tab_3_lite_7.0_ve'], 'Samsung Galaxy Note 8': ['note_8', 'note 8', 'note8'], 'Samsung Galaxy A71 5G': ['a71'], 'Samsung Galaxy A10 s': ['a10s', 'a10_s', 'a10 s'], 'Samsung Galaxy A42 5G': ['a42'], 'Samsung Galaxy A03 s': ['a03s', 'a03 s', 'a03_s'], 'Samsung Galaxy Tab Pro 12.2': ['tab_pro_12.2', 'tabpro12.2', 'tab pro 12.2'], 'Samsung Galaxy Tab E 9.6': ['tab e 9.6', 'tab_e_9.6', 'tabe9.6'], 'Samsung Galaxy A22': ['a22'], 'Samsung Galaxy S10 +': ['s10+', 's10_+', 's10 +'], 'Samsung Galaxy A5': ['a5'], 'Samsung Galaxy Tab S5 e': ['tabs5e', 'tab s5 e', 'tab_s5_e'], 'Samsung Galaxy A90 5G': ['a90'], 'Samsung Galaxy Tab Pro 8.4': ['tabpro8.4', 'tab pro 8.4', 'tab_pro_8.4'], 'Samsung Galaxy Tab S 10.5': ['tab s 10.5', 'tab_s_10.5', 'tabs10.5'], 'Samsung Galaxy Tab Advanced2': ['tabadvanced2', 'tab advanced2', 'tab_advanced2'], 'Samsung Galaxy S7': ['s7'], 'Samsung Galaxy Tab S2 8.0': ['tab s2 8.0', 'tabs28.0', 'tab_s2_8.0'], 'Samsung Galaxy A20 e': ['a20e', 'a20_e', 'a20 e'], 'Samsung Galaxy Tab Pro 10.1': ['tab pro 10.1', 'tabpro10.1', 'tab_pro_10.1'], 'Samsung Galaxy A70 s': ['a70_s', 'a70 s', 'a70s'], 'Samsung Galaxy A20': ['a20'], 'Samsung Galaxy A31': ['a31'], 'Samsung Galaxy Tab Pro 10.1 LTE': ['tab pro 10.1', 'tabpro10.1', 'tab_pro_10.1'], 'Samsung Galaxy S20 FE 5G': ['s20 fe', 's20fe', 's20_fe'], 'Samsung Galaxy A51 5G UW': ['a51_uw', 'a51 uw', 'a51uw'], 'Samsung Galaxy Z Fold 2 5G': ['z fold 2', 'zfold2', 'z_fold_2'], 'Samsung Galaxy Tab 4 8.0 LTE': ['tab 4 8.0', 'tab_4_8.0', 'tab48.0'], 'Samsung Galaxy Tab S7': ['tab_s7', 'tabs7', 'tab s7'], 'Samsung Galaxy S21 Ultra 5G': ['s21 ultra', 's21ultra', 's21_ultra'], 'Samsung Galaxy Note 7': ['note7', 'note_7', 'note 7'], 'Samsung Galaxy Tab A 8.4': ['taba8.4', 'tab a 8.4', 'tab_a_8.4'], 'Samsung Galaxy A71': ['a71'], 'Samsung Galaxy A5 Duos': ['a5 duos', 'a5duos', 'a5_duos'], 'Samsung Galaxy A3': ['a3'], 'Samsung Galaxy S21 FE 5G': ['s21 fe', 's21_fe', 's21fe'], 'Samsung Galaxy Tab A 10.5': ['taba10.5', 'tab_a_10.5', 'tab a 10.5'], 'Samsung Galaxy S20': ['s20'], 'Samsung Galaxy A30': ['a30'], 'Samsung Galaxy Tab 4 10.1 3G': ['tab410.1', 'tab 4 10.1', 'tab_4_10.1'], 'Samsung Galaxy Tab 4 7.0 3G': ['tab_4_7.0', 'tab 4 7.0', 'tab47.0'], 'Samsung Galaxy A52 s 5G': ['a52_s', 'a52 s', 'a52s'], 'Samsung Galaxy A Quantum': ['a_quantum', 'a quantum', 'aquantum'], 'Samsung Galaxy S20 5G': ['s20'], 'Samsung Galaxy Tab 3 Lite 7.0': ['tab 3 lite 7.0', 'tab3lite7.0', 'tab_3_lite_7.0'], 'Samsung Galaxy Tab Active 2': ['tabactive2', 'tab_active_2', 'tab active 2'], 'Samsung Galaxy A7': ['a7'], 'Samsung Galaxy A80': ['a80'], 'Samsung Galaxy S20 +': ['s20 +', 's20+', 's20_+'], 'iPhone 7': ['7'], 'iPhone 14 Plus': ['14_+', '14_plus', '14+', '14 +', '14plus', '14 plus'], 'iPhone 11 Pro Max': ['11 pro max', '11promax', '11_pro_max'], 'iPhone 6S Plus': ['6s +', '6s plus', '6s_plus', '6s+', '6splus', '6s_+'], 'iPhone 14 Pro': ['14_pro', '14pro', '14 pro'], 'iPhone 6S': ['6s'], 'iPhone XS': ['xs'], 'iPhone 8': ['8'], 'iPhone 8 Plus': ['8 +', '8+', '8_+', '8 plus', '8plus', '8_plus'], 'iPhone SE (2nd gen)': ['se 2 gen', 'se_2nd_gen', 'se2gen', 'se 2nd gen', 'se_2_gen', 'se2ndgen', 'se 2', 'se2'], 'iPhone 11': ['11'], 'iPhone SE (1st gen)': ['se_1st_gen', 'se1stgen', 'se 1st gen', 'se1gen', 'se_1_gen', 'se 1 gen', 'se', 'se 1', 'se1'], 'iPhone 6': ['6'], 'iPhone X': ['x'], 'iPhone 11 Pro': ['11pro', '11_pro', '11 pro'], 'iPhone SE (3rd gen)': ['se_3_gen', 'se_3rd_gen', 'se 3rd gen', 'se3rdgen', 'se 3 gen', 'se3gen', 'se 3', 'se3'], 'iPhone XR': ['xr'], 'iPhone 13 mini': ['13 mini', '13_mini', '13mini'], 'iPhone 12 Pro Max': ['12_pro_max', '12promax', '12 pro max'], 'iPhone 12': ['12'], 'iPhone XS Max': ['xsmax', 'xs_max', 'xs max'], 'iPhone 12 Pro': ['12pro', '12_pro', '12 pro'], 'iPhone 13': ['13'], 'iPhone 6 Plus': ['6plus', '6+', '6 +', '6_+', '6_plus', '6 plus'], 'iPhone 14': ['14'], 'iPhone 12 mini': ['12mini', '12_mini', '12 mini'], 'iPhone 7 Plus': ['7 +', '7+', '7_plus', '7_+', '7plus', '7 plus'], 'iPhone 14 Pro Max': ['14 pro max', '14_pro_max', '14promax'], 'iPhone 13 Pro': ['13_pro', '13pro', '13 pro'], 'iPhone 13 Pro Max': ['13 pro max', '13promax', '13_pro_max'], 'Tecno Pouvoir 2 Pro': ['pouvoir2pro', 'pouvoir 2 pro', 'pouvoir_2_pro'], 'Tecno Pop Pro': ['poppro', 'pop pro', 'pop_pro'], 'Tecno Camon CM': ['camoncm', 'camon_cm', 'camon cm'], 'Tecno Camon CX Air': ['camon cx air', 'camoncxair', 'camon_cx_air'], 'Tecno Pop': ['pop'], 'Tecno F2 LTE': ['f2_lte', 'f2 lte', 'f2lte'], 'Tecno Phantom 8': ['phantom_8', 'phantom 8', 'phantom8'], 'Tecno Pop Lite': ['poplite', 'pop_lite', 'pop lite'], 'Tecno Camon X': ['camonx', 'camon_x', 'camon x'], 'Tecno Phantom 6 Plus': ['phantom6+', 'phantom_6_plus', 'phantom 6 +', 'phantom 6 plus', 'phantom6plus', 'phantom_6_+'], 'Tecno Camon 11': ['camon_11', 'camon 11', 'camon11'], 'Tecno Spark Pro': ['spark pro', 'spark_pro', 'sparkpro'], 'Tecno Spark 2': ['spark_2', 'spark 2', 'spark2'], 'Tecno Phantom 6': ['phantom6', 'phantom_6', 'phantom 6'], 'Tecno Camon CX': ['camon_cx', 'camon cx', 'camoncx'], 'Tecno Pop s': ['pop_s', 'pop s', 'pops'], 'Tecno Pouvoir': ['pouvoir'], 'Tecno Spark Plus': ['spark_plus', 'sparkplus', 'spark_+', 'spark +', 'spark plus', 'spark+'], 'Tecno Spark': ['spark'], 'Tecno F2': ['f2'], 'Tecno Camon X Pro': ['camon x pro', 'camonxpro', 'camon_x_pro'], 'Tecno Spark CM': ['spark cm', 'spark_cm', 'sparkcm'], 'Tecno Pouvoir 2': ['pouvoir_2', 'pouvoir 2', 'pouvoir2']}


#### legacy ####

for tag in allproducts:
    temp = []
    for model in allproducts[tag]:
        temp.append(model.lower())
    allproducts[tag] = temp
print(allproducts)

# # lowercase로 변환
# for name in variations:
#     tempArr = []
#     for var in variations[name]:
#         t = var.lower()
#         tempArr.append(t)
#     variations[name] = variations[name] + tempArr
# print(variations)

# # 1st, 2nd, 3rd ... 숫자로 바꾸기
# for model in iPhone_products:
#     for each in iPhone_products[model]:
#         temp = re.sub('1st','1', each)
#         temp2 = re.sub('2nd', '2', each)
#         temp3 = re.sub('3rd', '3', each)
#         iPhone_products[model].append(temp)
#         iPhone_products[model].append(temp2)
#         iPhone_products[model].append(temp3)
#         iPhone_products[model] = list(set(iPhone_products[model]))
# print(iPhone_products)

# # 이거는 여러가지 버젼의 모델 이름 variation 만들기
# for model in tecno_products:
#     t1 = ""
#     t2 = ""
#     t3 = ""
#     for word in tecno_products[model]:
#         t1 = t1+word
#         t2 = t2+" "+word
#         t3 = t3+"_"+word
#
#     tecno_products[model] = list(set([t1, t2[1:], t3[1:]]))
# print(tecno_products)
#
# for model in tecno_products:
#     for word in tecno_products[model]:
#         temp = re.sub("Plus",r"+",word)
#         tecno_products[model].append(temp)
#         tecno_products[model] = list(set(tecno_products[model]))
# print(tecno_products)

# # 제품 리스트 다시 나누기
# lines = re.split("\n", tecno_raw)
# # stop = ["Samsung", "Galaxy", "5G", "LTE", "3G", "3G/LTE", "(2015)", "(2016)", "(2017)", "(2018)", "(2019)", "(2020)", "(2021)", "(2022)"]
# # stop = ["iPhone"]
# # stop = ['Camon', 'Phantom', 'Pouvoir', 'Spark', 'Pop', 'F2']
# stop = []
# out = {}
# productList = []
# for li in lines:
#     li = re.sub("\s\d{4}|\s\W\d{4}\W","", li)
#     productList.append(li)
#
# productList = list(set(productList))
# print(productList)
#
# for model in productList:
#     token = re.split("\s", model)
#     if token:
#         temp = []
#         for t in token:
#             if t not in stop:
#                 t = re.sub('\W',"",t)
#                 temp.append(t)
#     out[model] = temp
# print(out)

# line = "samsung galaxy s9+ (fissuré ) 40$ à discuter 0899125152"
#
# out = generate_variation("Galaxy", line)
# print(list(set(out)))
#
# for i in samsung["model"]:
#     out3 = []
#     out2 = generate_variation(i, line)
#     for o2 in out2:
#         if not o2 in out:
#             out3.append(o2)
#     out3 = list(set(out3))
#     print(out3)

# # 이거는 tecno
# splited = re.split("\n", tecno_raw)
# for line in splited:
#     model = re.findall("\w+", line)
#     if tecno:
#         tecno["model"].append(model[0])
#         if len(model) >=3:
#             tecno["version"].append(model[2])
#         else:
#             tecno["series"].append(model[1])


# # 이거는 iphone series 찾기
# splited = re.split("\n", iphone_raw)
# for model in apple["model"]:
#     for line in splited:
#         series = re.findall(r"{}\s(\w+)".format(model), line)
#         apple["series"].append(series[0])

# 이거는 iphone version 찾기
# splited = re.split("\n", iphone_raw)
# for model in apple["model"]:
#     for series in apple["series"]:
#         product = "{} {}".format(model, series)
#         for line in splited:
#             version = re.findall(r"{}\s(.+)".format(product), line)
#             if version:
#                 out = re.sub(r"[()]", "", version[0])
#                 apple["version"].append(out)

# #이거는 version 찾기
# splited = re.split("\n",samsung_raw)
# for model in samsung["model"]:
#     for series in samsung["series"]:
#         product = "Samsung {} {}".format(model, series)
#         for line in splited:
#             version = re.findall(r"{}\s(.+)".format(product), line)
#             if version:
#                 out = re.sub(r"\s*3G\s*|\s*5G\s*|\s*LTE\s*|\s*\W\d{4}\W\s*|\s*\d{4}\s*|\s*& S Pen\s*|/", "", version[0])
#                 samsung["version"].append(out)